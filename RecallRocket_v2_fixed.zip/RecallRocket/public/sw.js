/* Service worker: makes the app shell (and Chart.js / fonts once seen) available offline. API calls are never cached. */
const CACHE = "recallrocket-v2";
const SHELL = ["/", "/index.html", "/styles.css", "/js/core.js", "/js/api.js", "/js/state.js", "/js/ui.js", "/js/app.js"];

self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.pathname.startsWith("/api/")) return;
  const sameOrigin = url.origin === location.origin;
  const cdn = ["cdn.jsdelivr.net", "fonts.googleapis.com", "fonts.gstatic.com"].includes(url.hostname);
  if (!sameOrigin && !cdn) return;
  // stale-while-revalidate
  e.respondWith(caches.open(CACHE).then(async (cache) => {
    const cached = await cache.match(req, { ignoreSearch: false });
    const network = fetch(req).then((res) => { if (res && (res.ok || res.type === "opaque")) cache.put(req, res.clone()); return res; }).catch(() => cached);
    return cached || network;
  }));
});
