/*
 * state.js — the single client-side store.
 * Local-first: every change is written to localStorage immediately, then synced to the server
 * (debounced) using optimistic concurrency. Points / streak / totals are *derived* from the review log.
 */
(function () {
  "use strict";
  const RR = (window.RR = window.RR || {});
  const core = RR.core;
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

  const SAMPLE = [
    ["Algorithms", "Core problem-solving patterns and complexity.", "violet", [
      ["What is the average time complexity of QuickSort?", "O(n log n). Its worst case is O(n²), usually with consistently poor pivots."],
      ["What is the time complexity of Binary Search?", "O(log n), because the search space is halved at each step."],
      ["What is a stack?", "A LIFO data structure: the last item pushed is the first item popped."],
      ["What is a queue?", "A FIFO data structure: the first item enqueued is the first item dequeued."],
      ["What is a linked list?", "A sequence of nodes where each node stores data and a link to the next node."],
      ["What is a hash table?", "A key-value data structure using a hash function for average O(1) lookup."],
      ["What is recursion?", "A technique where a function solves a problem by calling itself on smaller inputs."],
      ["What is dynamic programming?", "Solving overlapping subproblems once and storing results for reuse."],
      ["What is the base case in recursion?", "The stopping condition that prevents recursive calls from continuing indefinitely."],
      ["What is a graph?", "A collection of vertices connected by edges; it may be directed or undirected."],
      ["What is BFS used for?", "Breadth-First Search explores level by level and finds shortest paths in unweighted graphs."],
      ["What is DFS?", "Depth-First Search explores one path deeply before backtracking."],
      ["What is a binary search tree?", "A binary tree where left descendants are smaller and right descendants are larger than a node."],
      ["What is a heap?", "A complete binary tree satisfying the min-heap or max-heap ordering property."],
      ["What is Big-O notation?", "A way to describe an algorithm's upper-bound growth rate as input size increases."]]],
    ["Computer Science", "Operating systems, databases and networks.", "blue", [
      ["What is an API?", "An Application Programming Interface defines how software components communicate."],
      ["What is HTTP?", "A request-response protocol used to transfer resources on the web."],
      ["What is REST?", "An architectural style for network APIs using stateless resources and standard HTTP methods."],
      ["What is a primary key?", "A column or set of columns that uniquely identifies each row in a database table."],
      ["What is normalization in databases?", "Organizing tables to reduce duplicate data and improve data integrity."],
      ["What is a process?", "A program in execution with its own memory space and resources."],
      ["What is a thread?", "A lightweight execution unit within a process; threads share process memory."],
      ["What is deadlock?", "A state where processes wait indefinitely for resources held by one another."],
      ["What is virtual memory?", "A memory-management technique that gives processes a large logical address space."],
      ["What is an operating system?", "System software that manages hardware, memory, processes, files, and user interaction."],
      ["What is a compiler?", "A program that translates source code into another form, often machine code."],
      ["What is polymorphism?", "The ability to use one interface with different underlying implementations."],
      ["What is encapsulation?", "Bundling data and methods while controlling access to an object's internal state."],
      ["What is inheritance?", "A mechanism where a class derives properties and behavior from another class."]]],
    ["Web Development", "Modern JavaScript, HTML and CSS concepts.", "mint", [
      ["What is a closure in JavaScript?", "A function bundled with references to its surrounding lexical environment."],
      ["What is the event loop?", "The JavaScript mechanism that coordinates the call stack and queued asynchronous callbacks."],
      ["What is a Promise?", "An object representing the eventual success or failure of an asynchronous operation."],
      ["What is SQL JOIN?", "A clause that combines rows from tables using a related column."],
      ["What is indexing in a database?", "A data structure that speeds up lookups, often at the cost of extra storage and writes."],
      ["What is a REST GET request for?", "Retrieving a resource without intentionally changing server state."],
      ["What is the difference between == and === in JavaScript?", "== allows type coercion; === compares value and type without coercion."],
      ["What is a CSS flex container?", "An element whose children are laid out along a flexible one-dimensional axis."],
      ["What is semantic HTML?", "HTML that uses elements according to their meaning and purpose."],
      ["What is responsive web design?", "Design that adapts layout and content to different screen sizes and devices."],
      ["What is Git?", "A distributed version-control system for tracking changes and collaborating on code."]]],
  ];
  const DEMO_COHORT = [
    { id: "demo1", name: "Aarav Mehta", points: 1240, streak: 12, reviewed: 186 },
    { id: "demo2", name: "Ishita Rao", points: 1085, streak: 9, reviewed: 161 },
    { id: "demo3", name: "Rohan Das", points: 920, streak: 7, reviewed: 142 },
    { id: "demo4", name: "Meera Shah", points: 780, streak: 5, reviewed: 118 },
  ];

  function makeCard(question, answer) {
    const today = core.dateKey();
    return { id: uid(), question, answer, easeFactor: 2.5, interval: 0, repetitions: 0, lapses: 0, nextReviewDate: today, createdAt: today, lastGrade: null, lastReviewed: null };
  }
  const seedDecks = () => SAMPLE.map(([name, description, color, cards]) => ({ id: uid(), name, description, color, cards: cards.map(([q, a]) => makeCard(q, a)) }));

  /* ---------------- store ---------------- */
  const S = { mode: "guest", user: null, decks: [], reviews: [], rev: 0, dirty: false, version: 0, sync: "local", syncDetail: "" };
  const listeners = new Set();
  const emit = () => listeners.forEach((f) => f());
  const onChange = (f) => listeners.add(f);
  const storageKey = () => `recallrocket:v2:${S.user ? S.user.id : "guest"}`;

  function saveLocal() {
    try { localStorage.setItem(storageKey(), JSON.stringify({ decks: S.decks, reviews: S.reviews, rev: S.rev, dirty: S.dirty })); }
    catch { setSync("local", "Browser storage is full — export a backup."); }
  }
  function readLocal() {
    try {
      const x = JSON.parse(localStorage.getItem(storageKey()));
      return x && Array.isArray(x.decks) && Array.isArray(x.reviews) ? x : null;
    } catch { return null; }
  }
  function setSync(status, detail = "") { S.sync = status; S.syncDetail = detail; emit(); }

  /** Apply a change, persist locally, schedule a server sync. */
  function mutate(fn) {
    fn(S);
    S.version++; S.dirty = true;
    saveLocal(); emit();
    if (S.mode === "user") scheduleSync();
  }

  let timer = null, syncing = false;
  const scheduleSync = () => { clearTimeout(timer); timer = setTimeout(sync, 400); };

  async function sync() {
    if (S.mode !== "user" || syncing) return;
    syncing = true;
    try {
      for (let attempt = 0; attempt < 3; attempt++) {
        const v = S.version;
        setSync("syncing");
        const r = await RR.api.putState({ decks: S.decks, reviews: S.reviews, baseRev: S.rev });
        if (r.status === 200) {
          S.rev = r.data.rev;
          if (S.version === v) S.dirty = false;
          saveLocal();
          if (!S.dirty) return setSync("synced");
          continue; // more edits arrived while saving
        }
        if (r.status === 409) { // another device wrote first → merge, retry
          const m = core.mergeStates({ decks: S.decks, reviews: S.reviews }, r.data);
          S.decks = m.decks; S.reviews = m.reviews; S.rev = r.data.rev; S.dirty = true; S.version++;
          saveLocal(); emit();
          continue;
        }
        if (r.status === 401) return setSync("signedout", "Session expired — sign in again to keep syncing.");
        if (r.status === 400) return setSync("rejected", (r.data && r.data.error) || "Server rejected the data.");
        return setSync("offline", "Server unavailable — changes are saved on this device.");
      }
    } catch { setSync("offline", "Offline — changes are saved on this device."); }
    finally { syncing = false; }
  }
  window.addEventListener("online", () => { if (S.dirty) sync(); });
  setInterval(() => { if (S.dirty && S.mode === "user" && !syncing) sync(); }, 30000);

  /* ---------------- lifecycle ---------------- */
  function useGuest() {
    S.mode = "guest"; S.user = null; S.rev = 0;
    const local = readLocal();
    if (local) { S.decks = local.decks; S.reviews = local.reviews; }
    else { S.decks = seedDecks(); S.reviews = []; saveLocal(); }
    S.dirty = false; setSync("local");
  }

  async function useUser(user) {
    S.mode = "user"; S.user = user;
    const local = readLocal();
    let remote = null;
    try { const r = await RR.api.getState(); if (r.ok) remote = r.data; } catch { /* offline */ }
    if (remote) {
      if (local && local.dirty) {
        const m = core.mergeStates(local, remote);
        Object.assign(S, { decks: m.decks, reviews: m.reviews, rev: remote.rev, dirty: true });
      } else Object.assign(S, { decks: remote.decks, reviews: remote.reviews, rev: remote.rev, dirty: false });
      if (!S.decks.length && !S.reviews.length && remote.rev === 0) { S.decks = seedDecks(); S.dirty = true; }
    } else if (local) Object.assign(S, { decks: local.decks, reviews: local.reviews, rev: local.rev, dirty: local.dirty });
    else Object.assign(S, { decks: [], reviews: [], rev: 0, dirty: false });
    S.version++; saveLocal(); setSync(remote ? "synced" : "offline");
    if (S.dirty) sync();
  }

  function clearUser() { try { localStorage.removeItem(storageKey()); } catch {} S.user = null; }

  /* ---------------- selectors ---------------- */
  const summary = () => core.summarise(S.reviews, core.dateKey());
  const allCards = () => S.decks.flatMap((d) => d.cards.map((c) => ({ ...c, deckId: d.id, deckName: d.name })));
  const isDue = (c, today = core.dateKey()) => c.nextReviewDate <= today;
  const dueCards = (deckId = null) => core.prioritise(allCards().filter((c) => isDue(c) && (!deckId || c.deckId === deckId)));
  const findDeck = (id) => S.decks.find((d) => d.id === id);

  RR.state = { S, onChange, mutate, sync, useGuest, useUser, clearUser, summary, allCards, dueCards, isDue, findDeck, makeCard, uid, seedDecks, DEMO_COHORT, setSync };
})();
