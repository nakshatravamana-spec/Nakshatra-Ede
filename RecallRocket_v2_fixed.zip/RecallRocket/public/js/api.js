/* api.js — thin fetch wrapper. Returns {status, ok, data}; throws only on network failure. */
(function () {
  "use strict";
  const RR = (window.RR = window.RR || {});

  async function request(method, url, body) {
    const res = await fetch(url, {
      method,
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Requested-With": "RecallRocket" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON body */ }
    return { status: res.status, ok: res.ok, data };
  }

  RR.api = {
    me: () => request("GET", "/api/auth/me"),
    register: (b) => request("POST", "/api/auth/register", b),
    login: (b) => request("POST", "/api/auth/login", b),
    logout: () => request("POST", "/api/auth/logout", {}),
    getState: () => request("GET", "/api/state"),
    putState: (b) => request("PUT", "/api/state", b),
    leaderboard: () => request("GET", "/api/leaderboard"),
    generate: (b) => request("POST", "/api/ai/generate", b),
    deleteAccount: (password) => request("DELETE", "/api/account", { password }),
  };
})();
