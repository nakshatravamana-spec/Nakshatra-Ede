/* ui.js — all DOM rendering. Reads state, never mutates it. Every dynamic string goes through escapeHTML or textContent. */
(function () {
  "use strict";
  const RR = (window.RR = window.RR || {});
  const core = RR.core, st = RR.state, S = st.S;
  const $ = (id) => document.getElementById(id);

  const escapeHTML = (s = "") => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const displayName = () => (S.user ? S.user.name : "Guest");

  function toast(msg) {
    const t = $("toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toast.timer); toast.timer = setTimeout(() => t.classList.remove("show"), 2600);
  }
  function greeting() {
    const h = new Date().getHours();
    return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  }

  /* ---------- decks ---------- */
  const DECK_ICON = { mint: "⌘", blue: "◈", orange: "✧", violet: "⌘" };
  function deckMarkup(d) {
    const due = d.cards.filter((c) => st.isDue(c)).length;
    const id = escapeHTML(d.id);
    return `<article class="deck-card"><button class="more" data-deck-menu="${id}" title="Manage deck" aria-label="Manage deck ${escapeHTML(d.name)}">···</button>` +
      `<div class="deck-color ${escapeHTML(d.color)}">${DECK_ICON[d.color] || "⌘"}</div><h4>${escapeHTML(d.name)}</h4>` +
      `<p>${escapeHTML(d.description || "Your custom learning deck")}</p>` +
      `<div class="deck-card-foot"><span>${d.cards.length} cards · ${due} due</span><div class="deck-actions">` +
      `<button data-study-deck="${id}">Study →</button><button data-add-card="${id}">＋ Card</button></div></div></article>`;
  }
  const emptyDecks = () => `<div class="panel"><p>No decks yet. Create your first deck to get started.</p></div>`;

  function renderDeckLists(filter = "") {
    const q = filter.trim().toLowerCase();
    const list = q ? S.decks.filter((d) => d.name.toLowerCase().includes(q) || (d.description || "").toLowerCase().includes(q) || d.cards.some((c) => c.question.toLowerCase().includes(q))) : S.decks;
    $("allDecks").innerHTML = list.map(deckMarkup).join("") || (q ? "<p class='muted-note'>No matching decks.</p>" : emptyDecks());
  }

  /* ---------- dashboard ---------- */
  function weekMarkup(studyDates) {
    const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], today = core.dateKey(), set = new Set(studyDates);
    return Array.from({ length: 7 }, (_, i) => {
      const key = core.addDays(today, i - 6), d = core.parseKey(key), active = set.has(key);
      return `<div class="week-day ${active ? "done" : ""}">${names[d.getDay()]}<i>${active ? "✓" : d.getDate()}</i></div>`;
    }).join("");
  }

  function renderDashboard(session) {
    const sum = st.summary(), due = st.dueCards().length, total = st.allCards().length;
    $("sidebarName").textContent = displayName();
    $("avatarInitial").textContent = (displayName()[0] || "G").toUpperCase();
    $("todayLabel").textContent = new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }).toUpperCase();
    $("dueStat").textContent = due; $("dueNavCount").textContent = due;
    $("streakStat").textContent = sum.streak; $("streakBig").textContent = sum.streak; $("sideStreak").textContent = `${sum.streak} day streak`;
    $("pointsStat").textContent = sum.points; $("reviewedStat").textContent = sum.reviewed;
    $("dueLine").style.width = (total ? Math.min(100, (due / total) * 100) : 0) + "%";
    $("reviewLine").style.width = (total ? Math.min(100, (sum.reviewed / (total + sum.reviewed)) * 100) : 0) + "%";
    $("streakDots").innerHTML = Array.from({ length: 7 }, (_, i) => `<i class="${i < Math.min(sum.streak, 7) ? "done" : ""}"></i>`).join("");
    $("queueTitle").textContent = due ? `${due} cards are ready for review` : "You're all caught up!";
    $("queueSub").textContent = due ? "A few focused minutes can make them stick." : "Add cards or come back tomorrow.";
    const pct = session.total ? Math.round((session.reviewed / session.total) * 100) : 0;
    $("queuePercent").textContent = pct + "%";
    $("progressRing").style.background = `conic-gradient(var(--purple) ${pct * 3.6}deg,#eeeafa 0deg)`;
    $("queueTrack").style.width = pct + "%";
    $("queueDone").textContent = `${session.reviewed} completed`; $("queueRemaining").textContent = `${due} due today`;
    $("weekRow").innerHTML = weekMarkup(sum.studyDates);
    $("dashboardDecks").innerHTML = S.decks.slice(0, 3).map(deckMarkup).join("") || emptyDecks();
    renderStatus();
    renderAccount();
  }

  const SYNC_TEXT = { local: "Saved on this device", syncing: "Syncing…", synced: "Synced to server", offline: "Offline · saved locally", signedout: "Signed out", rejected: "Sync error" };
  function renderStatus() {
    $("syncLabel").textContent = SYNC_TEXT[S.sync] || "Saved locally";
    $("syncLabel").title = S.syncDetail || "";
    $("syncLabel").parentElement.dataset.state = S.sync;
  }
  function renderAccount() {
    $("accountBtn").innerHTML = S.mode === "user" ? "<span>⎋</span> Sign out" : "<span>⎆</span> Sign in";
    document.querySelector(".profile-mini small").textContent = S.mode === "user" ? `@${S.user.username}` : "Guest · this device only";
    $("deleteAccountBtn").classList.toggle("hidden", S.mode !== "user");
  }

  /* ---------- leaderboard ---------- */
  function renderLeaderboard(data) {
    // data: {entries:[{rank,name,points,streak,reviewed,isMe}], me, total, demo}
    const me = data.me || { rank: "–", points: 0, streak: 0, reviewed: 0 };
    $("myRank").innerHTML = `#${escapeHTML(me.rank)} <span>↗</span>`;
    $("leaderPoints").textContent = me.points; $("leaderStreak").textContent = me.streak; $("leaderCards").textContent = me.reviewed;
    const medal = ["🥇", "🥈", "🥉"];
    $("leaderTable").innerHTML = `<div class="leader-row header"><span>RANK</span><span>LEARNER</span><span>POINTS</span><span>STREAK</span><span>REVIEWED</span></div>` +
      data.entries.map((u) => `<div class="leader-row ${u.isMe ? "me" : ""}"><span class="leader-rank">${u.rank <= 3 ? medal[u.rank - 1] : String(u.rank).padStart(2, "0")}</span>` +
        `<span class="leader-person"><i class="leader-avatar">${escapeHTML((u.name || "?")[0].toUpperCase())}</i>${escapeHTML(u.name)}${u.isMe ? " (You)" : ""}</span>` +
        `<span class="leader-value">${u.points}</span><span class="leader-value">♨ ${u.streak}</span><span class="leader-value">${u.reviewed}</span></div>`).join("");
    $("leaderNote").textContent = data.demo
      ? "You're in guest mode: the other learners are demo data. Sign in to compete with real classmates on a shared server."
      : `Ranking ${data.total} learner${data.total === 1 ? "" : "s"}. Points, streaks and totals are computed on the server from each learner's review history.`;
    $("leaderTag").textContent = data.demo ? "Demo cohort" : "Live · shared server";
  }
  function guestLeaderboard() {
    const sum = st.summary();
    const rows = [...st.DEMO_COHORT, { id: "me", name: `${displayName()}`, points: sum.points, streak: sum.streak, reviewed: sum.reviewed, isMe: true }]
      .sort((a, b) => b.points - a.points).map((u, i) => ({ ...u, rank: i + 1 }));
    return { entries: rows, me: rows.find((u) => u.isMe), total: rows.length, demo: true };
  }

  /* ---------- insights ---------- */
  let charts = {};
  function renderCharts() {
    renderLeeches();
    if (!window.Chart) { $("chartOffline").classList.remove("hidden"); return; }
    $("chartOffline").classList.add("hidden");
    const today = core.dateKey();
    const days = Array.from({ length: 7 }, (_, i) => core.addDays(today, i - 6));
    const labels = days.map((k) => core.parseKey(k).toLocaleDateString(undefined, { weekday: "short" }));
    const counts = days.map((k) => S.reviews.filter((r) => r.date === k).length);
    const grid = { color: "rgba(130,130,160,.12)" };
    const make = (id, cfg) => { if (charts[id]) charts[id].destroy(); charts[id] = new Chart($(id), cfg); };

    make("activityChart", { type: "bar", data: { labels, datasets: [{ label: "Cards reviewed", data: counts, backgroundColor: "#8c73ef", borderRadius: 6, maxBarThickness: 28 }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 }, grid }, x: { grid: { display: false } } } } });

    make("retentionChart", { type: "line", data: { labels: ["0h", "12h", "1d", "2d", "4d", "7d", "14d"], datasets: [
      { label: "Without review", data: [100, 75, 58, 42, 27, 16, 8], borderColor: "#ef9c58", backgroundColor: "#ef9c5822", fill: true, tension: 0.35 },
      { label: "After recall practice", data: [100, 90, 84, 78, 72, 65, 57], borderColor: "#7658e8", backgroundColor: "#7658e822", fill: true, tension: 0.35 }] },
      options: { plugins: { legend: { labels: { boxWidth: 8, font: { size: 9 } } } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + "%" }, grid }, x: { grid: { display: false } } } } });

    const real = core.retentionByInterval(S.reviews);
    $("realRetentionNote").textContent = S.reviews.length < 10 ? "Review at least 10 cards to see your real recall rates." : "Share of reviews graded 3 or higher, grouped by how long the card had been left since its previous review.";
    make("realChart", { type: "bar", data: { labels: real.map((r) => `${r.label} (n=${r.n})`), datasets: [{ label: "Recall rate", data: real.map((r) => r.rate), backgroundColor: "#19a982", borderRadius: 6, maxBarThickness: 40 }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + "%" }, grid }, x: { grid: { display: false } } } } });
  }
  function renderLeeches() {
    const leeches = st.allCards().filter(core.isLeech);
    $("leechList").innerHTML = leeches.length
      ? leeches.slice(0, 8).map((c) => `<li><b>${escapeHTML(c.deckName)}</b> — ${escapeHTML(c.question)} <small>(${c.lapses} lapses)</small></li>`).join("")
      : "<li class='muted-note'>No leeches — no card has been forgotten 4+ times.</li>";
  }

  /* ---------- deck manager ---------- */
  function renderManager(deck) {
    $("mgrName").value = deck.name; $("mgrDesc").value = deck.description || ""; $("mgrColor").value = deck.color;
    $("mgrCount").textContent = `${deck.cards.length} card${deck.cards.length === 1 ? "" : "s"}`;
    $("mgrCards").innerHTML = deck.cards.map((c) =>
      `<li><span class="mgr-q">${core.isLeech(c) ? '<em class="leech" title="Forgotten 4+ times">leech</em> ' : ""}${escapeHTML(c.question)}</span>` +
      `<span class="mgr-actions"><button type="button" data-edit-card="${escapeHTML(c.id)}">Edit</button><button type="button" data-del-card="${escapeHTML(c.id)}">Delete</button></span></li>`).join("") || "<li class='muted-note'>No cards yet.</li>";
  }

  RR.ui = { $, escapeHTML, toast, greeting, displayName, renderDashboard, renderDeckLists, renderStatus, renderLeaderboard, guestLeaderboard, renderCharts, renderManager, deckMarkup };
})();
