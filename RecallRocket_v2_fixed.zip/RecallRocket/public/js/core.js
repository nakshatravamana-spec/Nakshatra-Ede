/*
 * core.js — pure, dependency-free domain logic shared by the browser and the Node server.
 * UMD wrapper: window.RR.core in the browser, module.exports under Node (so tests can require it).
 * Nothing here touches the DOM, the network or the clock unless a `now` is passed in.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else { root.RR = root.RR || {}; root.RR.core = api; }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const LIMITS = Object.freeze({
    deckName: 45, deckDesc: 100, question: 400, answer: 600,
    decks: 100, cardsPerDeck: 2000, reviews: 50000, csvRows: 2000, reviewsPerDay: 1000,
  });
  const POINTS_BY_GRADE = Object.freeze([0, 1, 2, 5, 8, 10]);
  const COLORS = Object.freeze(["violet", "mint", "blue", "orange"]);
  const MIN_EF = 1.3;
  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

  /* ---------- dates (all keys are local-calendar YYYY-MM-DD strings) ---------- */
  const pad = (n) => String(n).padStart(2, "0");
  function dateKey(d = new Date()) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
  function parseKey(key) { const [y, m, d] = key.split("-").map(Number); return new Date(y, m - 1, d, 12); } // noon: DST-safe
  function addDays(key, n) { const d = parseKey(key); d.setDate(d.getDate() + n); return dateKey(d); }
  function isValidKey(s) {
    if (typeof s !== "string" || !DATE_RE.test(s)) return false;
    const d = parseKey(s); return dateKey(d) === s;
  }
  function daysBetween(a, b) { return Math.round((parseKey(b) - parseKey(a)) / 864e5); }

  /* ---------- SM-2 ---------- */
  /**
   * SuperMemo-2. grade 0–5. Returns the card's new scheduling fields without mutating the card.
   * grade < 3  → lapse: repetitions reset, interval 1 day.
   * grade >= 3 → 1 day, then 6 days, then round(previous interval × EF).
   * EF' = EF + (0.1 − (5−q)(0.08 + (5−q)0.02)), floored at 1.3.
   */
  function sm2(grade, card, today = dateKey()) {
    if (!Number.isInteger(grade) || grade < 0 || grade > 5) throw new RangeError("grade must be an integer 0-5");
    let ef = Number(card.easeFactor) || 2.5;
    let reps = Number(card.repetitions) || 0;
    let interval = Number(card.interval) || 0;
    let lapses = Number(card.lapses) || 0;
    if (grade < 3) { reps = 0; interval = 1; lapses++; }
    else {
      interval = reps === 0 ? 1 : reps === 1 ? 6 : Math.round(interval * ef);
      reps++;
    }
    ef = Math.max(MIN_EF, ef + (0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02)));
    return { easeFactor: Number(ef.toFixed(2)), repetitions: reps, interval, lapses, nextReviewDate: addDays(today, interval) };
  }

  /* ---------- streaks, points, stats ---------- */
  function calcStreak(studyDates, today = dateKey()) {
    const set = new Set(studyDates || []);
    let key = set.has(today) ? today : addDays(today, -1);
    let n = 0;
    while (set.has(key)) { n++; key = addDays(key, -1); }
    return n;
  }
  const pointsFor = (grade) => POINTS_BY_GRADE[grade] ?? 0;

  /** Derive leaderboard numbers from the review log (server never trusts client-supplied totals). */
  function summarise(reviews, today = dateKey()) {
    let points = 0; const dates = new Set();
    for (const r of reviews) { points += pointsFor(r.grade); dates.add(r.date); }
    return { points, reviewed: reviews.length, streak: calcStreak([...dates], today), studyDates: [...dates].sort() };
  }

  /** Overdue cards first (most overdue → least), then lapsed/hard cards, then new. Stable. */
  function prioritise(cards, today = dateKey()) {
    const score = (c) => daysBetween(c.nextReviewDate, today) * 10 + (c.lapses || 0) * 2 - (c.repetitions || 0) * 0.01;
    return cards.map((c, i) => [c, i]).sort((a, b) => score(b[0]) - score(a[0]) || a[1] - b[1]).map((x) => x[0]);
  }
  const isLeech = (c) => (c.lapses || 0) >= 4;

  /** Real recall rate by interval bucket computed from the user's own history (used for the insights chart). */
  function retentionByInterval(reviews) {
    const buckets = [["1d", 1, 1], ["2-3d", 2, 3], ["4-7d", 4, 7], ["8-14d", 8, 14], ["15d+", 15, Infinity]];
    return buckets.map(([label, lo, hi]) => {
      const rs = reviews.filter((r) => r.prevInterval >= lo && r.prevInterval <= hi);
      return { label, n: rs.length, rate: rs.length ? Math.round(rs.filter((r) => r.grade >= 3).length / rs.length * 100) : null };
    });
  }

  /* ---------- sanitising / validation ---------- */
  const clean = (v, max) => String(v ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, max);
  const isId = (s) => typeof s === "string" && /^[\w-]{1,80}$/.test(s);

  function sanitiseCard(c) {
    if (!c || typeof c !== "object") return null;
    const question = clean(c.question, LIMITS.question), answer = clean(c.answer, LIMITS.answer);
    if (!isId(c.id) || !question || !answer) return null;
    const num = (v, lo, hi, d) => (Number.isFinite(Number(v)) ? Math.min(hi, Math.max(lo, Number(v))) : d);
    return {
      id: c.id, question, answer,
      easeFactor: num(c.easeFactor, MIN_EF, 5, 2.5),
      interval: Math.round(num(c.interval, 0, 36500, 0)),
      repetitions: Math.round(num(c.repetitions, 0, 10000, 0)),
      lapses: Math.round(num(c.lapses, 0, 10000, 0)),
      nextReviewDate: isValidKey(c.nextReviewDate) ? c.nextReviewDate : dateKey(),
      createdAt: isValidKey(c.createdAt) ? c.createdAt : dateKey(),
      lastReviewed: isValidKey(c.lastReviewed) ? c.lastReviewed : null,
      lastGrade: Number.isInteger(c.lastGrade) && c.lastGrade >= 0 && c.lastGrade <= 5 ? c.lastGrade : null,
    };
  }
  function sanitiseDeck(d) {
    if (!d || typeof d !== "object" || !isId(d.id) || !Array.isArray(d.cards)) return null;
    const name = clean(d.name, LIMITS.deckName);
    if (!name) return null;
    const seen = new Set(), cards = [];
    for (const raw of d.cards.slice(0, LIMITS.cardsPerDeck)) {
      const c = sanitiseCard(raw);
      if (c && !seen.has(c.id)) { seen.add(c.id); cards.push(c); }
    }
    return { id: d.id, name, description: clean(d.description, LIMITS.deckDesc), color: COLORS.includes(d.color) ? d.color : "violet", cards };
  }
  /** Validate a review entry. `maxDate` is the latest acceptable calendar day (server passes UTC today + 1). */
  function sanitiseReview(r, maxDate) {
    if (!r || typeof r !== "object" || !isId(r.id) || !isId(r.cardId) || !isId(r.deckId)) return null;
    if (!Number.isInteger(r.grade) || r.grade < 0 || r.grade > 5) return null;
    if (!isValidKey(r.date) || (maxDate && r.date > maxDate)) return null;
    const prev = Number.isFinite(Number(r.prevInterval)) ? Math.min(36500, Math.max(0, Math.round(Number(r.prevInterval)))) : 0;
    return { id: r.id, cardId: r.cardId, deckId: r.deckId, grade: r.grade, date: r.date, points: pointsFor(r.grade), interval: Math.round(Number(r.interval) || 0), prevInterval: prev };
  }
  /** Whole-state validation. Returns {ok:true,value} or {ok:false,error}. Never throws. */
  function validateState(state, maxDate) {
    if (!state || typeof state !== "object") return { ok: false, error: "State must be an object." };
    if (!Array.isArray(state.decks)) return { ok: false, error: "decks must be an array." };
    if (!Array.isArray(state.reviews)) return { ok: false, error: "reviews must be an array." };
    if (state.decks.length > LIMITS.decks) return { ok: false, error: `Too many decks (max ${LIMITS.decks}).` };
    if (state.reviews.length > LIMITS.reviews) return { ok: false, error: `Too many reviews (max ${LIMITS.reviews}).` };
    const ids = new Set(), decks = [];
    for (const d of state.decks) {
      const s = sanitiseDeck(d);
      if (!s) return { ok: false, error: "Invalid deck structure." };
      if (ids.has(s.id)) return { ok: false, error: "Duplicate deck id." };
      ids.add(s.id); decks.push(s);
    }
    const reviews = [], perDay = new Map();
    for (const r of state.reviews) {
      const s = sanitiseReview(r, maxDate);
      if (!s) return { ok: false, error: "Invalid review entry." };
      const n = (perDay.get(s.date) || 0) + 1;
      if (n > LIMITS.reviewsPerDay) return { ok: false, error: "Implausible review volume for one day." };
      perDay.set(s.date, n); reviews.push(s);
    }
    return { ok: true, value: { decks, reviews } };
  }

  /**
   * Merge a stale local state with the server's current state after a 409 conflict.
   * Decks/cards: union by id, newest review wins per card. Reviews: union by id.
   * Known limitation: a deletion made on a stale device can be resurrected by the merge.
   */
  function mergeStates(local, remote) {
    const decks = new Map(remote.decks.map((d) => [d.id, { ...d, cards: [...d.cards] }]));
    for (const ld of local.decks) {
      const rd = decks.get(ld.id);
      if (!rd) { decks.set(ld.id, ld); continue; }
      const byId = new Map(rd.cards.map((c) => [c.id, c]));
      for (const lc of ld.cards) {
        const rc = byId.get(lc.id);
        if (!rc || (lc.lastReviewed || "") > (rc.lastReviewed || "")) byId.set(lc.id, lc);
      }
      rd.cards = [...byId.values()];
    }
    const seen = new Set(), reviews = [];
    for (const r of [...remote.reviews, ...local.reviews]) if (!seen.has(r.id)) { seen.add(r.id); reviews.push(r); }
    return { decks: [...decks.values()], reviews };
  }

  /* ---------- CSV ---------- */
  function parseCSV(text) {
    const rows = []; let row = [], cell = "", quoted = false;
    const endRow = () => { row.push(cell); if (row.some((x) => x.trim())) rows.push(row); row = []; cell = ""; };
    for (let i = 0; i < text.length; i++) {
      const c = text[i], n = text[i + 1];
      if (c === '"' && quoted && n === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = !quoted;
      else if (c === "," && !quoted) { row.push(cell); cell = ""; }
      else if ((c === "\n" || c === "\r") && !quoted) { if (c === "\r" && n === "\n") i++; endRow(); }
      else cell += c;
    }
    endRow();
    return rows;
  }
  /** Neutralise spreadsheet formula injection (=, +, -, @, tab, CR) when exporting. */
  const csvCell = (v) => { let s = String(v ?? ""); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return `"${s.replace(/"/g, '""')}"`; };

  return { LIMITS, POINTS_BY_GRADE, COLORS, MIN_EF, dateKey, parseKey, addDays, isValidKey, daysBetween, sm2, calcStreak, pointsFor, summarise, prioritise, isLeech, retentionByInterval, clean, isId, sanitiseCard, sanitiseDeck, sanitiseReview, validateState, mergeStates, parseCSV, csvCell };
});
