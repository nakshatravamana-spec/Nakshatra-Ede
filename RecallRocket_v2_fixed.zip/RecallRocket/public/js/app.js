/* app.js — controller: navigation, study session, CRUD, import/export, auth flow, event wiring. */
(function () {
  "use strict";
  const RR = window.RR, core = RR.core, st = RR.state, ui = RR.ui, api = RR.api, S = st.S;
  const { $, toast, escapeHTML } = ui;

  let currentView = "dashboard";
  let session = { queue: [], index: 0, reviewed: 0, points: 0, total: 0 };
  let editingCardId = null, editingDeckId = null, managerDeckId = null, authMode = "login", renderQueued = false;

  /* ---------------- rendering ---------------- */
  function renderAll() {
    ui.renderDashboard(session);
    ui.renderDeckLists($("deckSearch").value);
    if (managerDeckId && $("managerDialog").open) { const d = st.findDeck(managerDeckId); if (d) ui.renderManager(d); }
  }
  const queueRender = () => { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; renderAll(); }); };

  function navigate(view) {
    currentView = view;
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === view + "View"));
    document.querySelectorAll(".nav-link[data-view]").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
    const titles = { dashboard: `${ui.greeting()}, ${ui.displayName()}`, study: "Time to recall", decks: "Your knowledge library", leaderboard: "Learn together, rise together", analytics: "Your memory insights" };
    $("pageTitle").innerHTML = escapeHTML(titles[view] || "RecallRocket") + (view === "dashboard" ? " <span>✦</span>" : "");
    if (view === "study") startSession();
    if (view === "analytics") ui.renderCharts();
    if (view === "leaderboard") loadLeaderboard();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function loadLeaderboard() {
    if (S.mode !== "user") return ui.renderLeaderboard(ui.guestLeaderboard());
    try {
      if (S.dirty) await st.sync();
      const r = await api.leaderboard();
      if (r.ok) ui.renderLeaderboard({ ...r.data, demo: false });
      else toast((r.data && r.data.error) || "Could not load leaderboard.");
    } catch { toast("Leaderboard unavailable offline."); }
  }

  /* ---------------- study session ---------------- */
  function startSession(deckId = null) {
    const cards = st.dueCards(deckId);
    session = { queue: cards.map((c) => ({ id: c.id, deckId: c.deckId })), index: 0, reviewed: 0, points: 0, total: cards.length };
    $("studyDeckName").textContent = deckId ? (st.findDeck(deckId) || {}).name || "Selected deck" : "All decks";
    updateStudyCard();
    renderAll();
  }

  function updateStudyCard() {
    const { queue, index, total } = session;
    const item = queue[index], deck = item && st.findDeck(item.deckId), card = deck && deck.cards.find((c) => c.id === item.id);
    $("studyProgress").textContent = `${Math.min(index, total)} / ${total} cards`;
    $("studyProgressBar").style.width = (total ? (index / total) * 100 : 0) + "%";
    $("sessionReviewed").textContent = session.reviewed; $("sessionPoints").textContent = session.points; $("sessionRemaining").textContent = Math.max(0, total - index);
    const done = !card;
    $("flashcardWrap").classList.toggle("hidden", done);
    $("ratingArea").classList.toggle("hidden", done);
    $("studyEmpty").classList.toggle("hidden", !done);
    if (done) {
      $("studyEmpty").querySelector("h3").textContent = total ? "Session complete!" : "You're clear for take-off!";
      $("studyEmpty").querySelector("p").textContent = total ? `You reviewed ${session.reviewed} cards and earned ${session.points} memory points. Great work.` : "No cards are due right now. Add a new card or check back later.";
      return;
    }
    $("flashcard").classList.remove("flipped");
    $("questionText").textContent = card.question;
    $("answerText").textContent = card.answer;
    $("cardDeck").textContent = deck.name.toUpperCase() + (core.isLeech(card) ? " · LEECH" : "");
    $("cardIndex").textContent = `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`;
  }

  const flipCard = () => { if (session.queue[session.index]) $("flashcard").classList.toggle("flipped"); };

  function rateCard(grade) {
    const item = session.queue[session.index];
    if (!item || !$("flashcard").classList.contains("flipped")) return toast("Flip the card to reveal the answer first.");
    const deck = st.findDeck(item.deckId), card = deck && deck.cards.find((c) => c.id === item.id);
    if (!card) { session.index++; return updateStudyCard(); } // card deleted mid-session
    const today = core.dateKey(), prevInterval = card.interval;
    const result = core.sm2(grade, card, today), points = core.pointsFor(grade);
    st.mutate((s) => {
      Object.assign(card, result, { lastGrade: grade, lastReviewed: today });
      s.reviews.push({ id: st.uid(), cardId: card.id, deckId: deck.id, grade, date: today, points, interval: result.interval, prevInterval });
    });
    session.reviewed++; session.points += points; session.index++;
    updateStudyCard(); renderAll();
    toast(session.index >= session.queue.length ? `Session complete! +${session.points} memory points`
      : `Next review in ${result.interval} day${result.interval === 1 ? "" : "s"} · +${points} points`);
  }

  /* ---------------- decks & cards ---------------- */
  function openCreateDeck() {
    $("newDeckName").value = ""; $("newDeckDesc").value = ""; $("newDeckColor").value = "violet";
    $("deckDialog").showModal(); $("newDeckName").focus();
  }
  function saveNewDeck(e) {
    e.preventDefault();
    if (!$("deckForm").reportValidity()) return;
    const name = core.clean($("newDeckName").value, core.LIMITS.deckName);
    if (!name) return toast("Give your deck a name.");
    if (S.decks.length >= core.LIMITS.decks) return toast("Deck limit reached.");
    st.mutate((s) => s.decks.push({ id: st.uid(), name, description: core.clean($("newDeckDesc").value, core.LIMITS.deckDesc), color: $("newDeckColor").value, cards: [] }));
    $("deckDialog").close(); toast("Deck created");
  }

  function openManager(deckId) {
    const d = st.findDeck(deckId); if (!d) return;
    managerDeckId = deckId; ui.renderManager(d); $("managerDialog").showModal();
  }
  function saveManager() {
    const d = st.findDeck(managerDeckId); if (!d) return;
    const name = core.clean($("mgrName").value, core.LIMITS.deckName);
    if (!name) return toast("Deck name can't be empty.");
    st.mutate(() => Object.assign(d, { name, description: core.clean($("mgrDesc").value, core.LIMITS.deckDesc), color: $("mgrColor").value }));
    toast("Deck updated");
  }
  function deleteDeck() {
    const d = st.findDeck(managerDeckId); if (!d) return;
    if (!confirm(`Delete "${d.name}" and its ${d.cards.length} cards? This can't be undone.`)) return;
    st.mutate((s) => { s.decks = s.decks.filter((x) => x.id !== d.id); });
    $("managerDialog").close(); toast("Deck deleted");
  }

  function openCardDialog(deckId, cardId = null) {
    if (!S.decks.length) return toast("Create a deck first.");
    const deck = st.findDeck(deckId) || S.decks[0];
    const card = cardId ? deck.cards.find((c) => c.id === cardId) : null;
    editingCardId = card ? card.id : null; editingDeckId = deck.id;
    // Populated here (not on every render) so a background re-render can never reset the user's selection mid-edit.
    $("cardDeckSelect").innerHTML = S.decks.map((d) => `<option value="${escapeHTML(d.id)}">${escapeHTML(d.name)}</option>`).join("");
    $("cardDeckSelect").value = deck.id;
    $("cardDeckSelect").disabled = !!card;
    $("cardModalTitle").textContent = card ? "Edit flashcard" : "Add a flashcard";
    $("newQuestion").value = card ? card.question : ""; $("newAnswer").value = card ? card.answer : "";
    $("cardDialog").showModal(); $("newQuestion").focus();
  }
  function saveCard(e) {
    e.preventDefault();
    if (!$("cardForm").reportValidity()) return;
    const deck = st.findDeck(editingCardId ? editingDeckId : $("cardDeckSelect").value);
    const question = core.clean($("newQuestion").value, core.LIMITS.question), answer = core.clean($("newAnswer").value, core.LIMITS.answer);
    if (!deck || !question || !answer) return toast("Both question and answer are required.");
    if (editingCardId) {
      const card = deck.cards.find((c) => c.id === editingCardId);
      if (!card) { $("cardDialog").close(); return toast("That card no longer exists."); }
      st.mutate(() => Object.assign(card, { question, answer }));
    } else {
      if (deck.cards.length >= core.LIMITS.cardsPerDeck) return toast("This deck is full.");
      st.mutate(() => deck.cards.push(st.makeCard(question, answer)));
    }
    const wasEdit = !!editingCardId;
    $("cardDialog").close(); toast(wasEdit ? "Card updated" : `Flashcard added to ${deck.name}`);
  }
  function deleteCard(cardId) {
    const d = st.findDeck(managerDeckId); if (!d || !confirm("Delete this card?")) return;
    st.mutate(() => { d.cards = d.cards.filter((c) => c.id !== cardId); });
  }

  /* ---------------- import / export ---------------- */
  function downloadBlob(blob, name) {
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function exportCSV(deck = null) {
    const decks = deck ? [deck] : S.decks;
    const rows = [["Deck", "Question", "Answer", "EaseFactor", "Interval", "Repetitions", "NextReviewDate"],
      ...decks.flatMap((d) => d.cards.map((c) => [d.name, c.question, c.answer, c.easeFactor, c.interval, c.repetitions, c.nextReviewDate]))];
    downloadBlob(new Blob([rows.map((r) => r.map(core.csvCell).join(",")).join("\n")], { type: "text/csv" }), deck ? `${deck.name.replace(/\W+/g, "_")}.csv` : "recallrocket-cards.csv");
  }
  function exportBackup() {
    downloadBlob(new Blob([JSON.stringify({ decks: S.decks, reviews: S.reviews, exportedAt: new Date().toISOString() }, null, 2)], { type: "application/json" }), "recallrocket-backup.json");
    toast("Backup exported.");
  }
  async function importCSV(file) {
    if (file.size > 1024 * 1024) return toast("CSV is too large (max 1 MB).");
    const rows = core.parseCSV(await file.text());
    if (rows.length < 2) return toast("CSV has no card rows.");
    const header = rows.shift().map((x) => x.toLowerCase().trim());
    const col = (names) => header.findIndex((h) => names.includes(h));
    const qi = col(["question", "front", "prompt"]), ai = col(["answer", "back", "response"]), di = col(["deck", "deckname", "subject"]);
    if (qi < 0 || ai < 0) return toast("CSV needs Question and Answer columns.");
    let added = 0, skipped = 0;
    st.mutate((s) => {
      for (const row of rows.slice(0, core.LIMITS.csvRows)) {
        const q = core.clean(row[qi], core.LIMITS.question), a = core.clean(row[ai], core.LIMITS.answer);
        const name = core.clean(di >= 0 ? row[di] : "", core.LIMITS.deckName) || "Imported deck";
        if (!q || !a) { skipped++; continue; }
        let d = s.decks.find((x) => x.name.toLowerCase() === name.toLowerCase());
        if (!d) { if (s.decks.length >= core.LIMITS.decks) { skipped++; continue; } d = { id: st.uid(), name, description: "Imported flashcards", color: "blue", cards: [] }; s.decks.push(d); }
        if (d.cards.length >= core.LIMITS.cardsPerDeck || d.cards.some((c) => c.question === q)) { skipped++; continue; }
        d.cards.push(st.makeCard(q, a)); added++;
      }
    });
    toast(`${added} cards imported${skipped ? `, ${skipped} skipped` : ""}.`);
  }

  /* ---------------- AI generation ---------------- */
  function openAI() {
    if (S.mode !== "user") return toast("Sign in to use AI card generation.");
    if (!S.decks.length) return toast("Create a deck first.");
    $("aiDeck").innerHTML = S.decks.map((d) => `<option value="${escapeHTML(d.id)}">${escapeHTML(d.name)}</option>`).join("");
    $("aiError").textContent = ""; $("aiDialog").showModal(); $("aiTopic").focus();
  }
  async function runAI(e) {
    e.preventDefault();
    if (!$("aiForm").reportValidity()) return;
    const btn = $("aiGoBtn"); btn.disabled = true; btn.textContent = "Generating…"; $("aiError").textContent = "";
    try {
      const r = await api.generate({ topic: $("aiTopic").value, count: Number($("aiCount").value) });
      if (!r.ok) { $("aiError").textContent = (r.data && r.data.error) || "Generation failed."; return; }
      const deck = st.findDeck($("aiDeck").value);
      st.mutate(() => r.data.cards.forEach((c) => deck.cards.push(st.makeCard(c.question, c.answer))));
      $("aiDialog").close(); toast(`${r.data.cards.length} AI cards added to ${deck.name}`);
    } catch { $("aiError").textContent = "Couldn't reach the server."; }
    finally { btn.disabled = false; btn.textContent = "Generate cards"; }
  }

  /* ---------------- accounts ---------------- */
  function openAuth(mode = "login") {
    authMode = mode;
    $("authTitle").textContent = mode === "login" ? "Welcome back" : "Create your account";
    $("authSubmit").textContent = mode === "login" ? "Sign in" : "Create account";
    $("authSwitch").textContent = mode === "login" ? "New here? Create an account" : "Have an account? Sign in";
    $("authNameLabel").classList.toggle("hidden", mode === "login");
    $("authPassword").autocomplete = mode === "login" ? "current-password" : "new-password";
    $("authError").textContent = "";
    if (!$("authDialog").open) $("authDialog").showModal();
  }
  async function submitAuth(e) {
    e.preventDefault();
    if (!$("authForm").reportValidity()) return;
    const body = { username: $("authUsername").value, password: $("authPassword").value, displayName: $("authName").value };
    $("authSubmit").disabled = true; $("authError").textContent = "";
    try {
      const r = await (authMode === "login" ? api.login(body) : api.register(body));
      if (!r.ok) { $("authError").textContent = (r.data && r.data.error) || "Something went wrong."; return; }
      $("authPassword").value = "";
      if (S.mode === "guest") st.clearUser(); // guest data stays under its own key
      await st.useUser(r.data.user);
      $("authDialog").close(); session = { queue: [], index: 0, reviewed: 0, points: 0, total: 0 };
      renderAll(); navigate("dashboard"); toast(`Signed in as ${r.data.user.name}`);
    } catch { $("authError").textContent = "Can't reach the server. You can continue as a guest."; }
    finally { $("authSubmit").disabled = false; }
  }
  async function accountClick() {
    if (S.mode !== "user") return openAuth("login");
    try { await api.logout(); } catch {}
    st.clearUser(); st.useGuest(); session = { queue: [], index: 0, reviewed: 0, points: 0, total: 0 };
    renderAll(); navigate("dashboard"); toast("Signed out");
  }
  async function submitDelete(e) {
    e.preventDefault();
    const r = await api.deleteAccount($("deletePassword").value).catch(() => null);
    if (!r || !r.ok) { $("deleteError").textContent = (r && r.data && r.data.error) || "Could not delete account."; return; }
    $("deletePassword").value = ""; $("deleteDialog").close();
    st.clearUser(); st.useGuest(); renderAll(); navigate("dashboard"); toast("Account deleted");
  }

  /* ---------------- events ---------------- */
  function setupEvents() {
    document.querySelectorAll(".nav-link[data-view]").forEach((b) => b.addEventListener("click", () => navigate(b.dataset.view)));
    document.querySelectorAll("[data-goto]").forEach((b) => b.addEventListener("click", () => navigate(b.dataset.goto)));
    $("quickStudyBtn").onclick = $("heroStudyBtn").onclick = () => navigate("study");
    $("createDeckBtn").onclick = openCreateDeck;
    $("deckForm").addEventListener("submit", saveNewDeck); $("saveDeckBtn").addEventListener("click", saveNewDeck);
    $("cardForm").addEventListener("submit", saveCard); $("saveCardBtn").addEventListener("click", saveCard);
    $("flashcard").addEventListener("click", flipCard);
    $("ratingArea").addEventListener("click", (e) => { const b = e.target.closest("[data-grade]"); if (b) rateCard(Number(b.dataset.grade)); });
    $("endSessionBtn").onclick = () => { toast(`Session saved · ${session.reviewed} reviewed`); navigate("dashboard"); };
    $("themeToggle").onclick = () => { document.body.classList.toggle("dark"); try { localStorage.setItem("recallrocket-dark", document.body.classList.contains("dark")); } catch {} };
    $("exportBtn").onclick = exportBackup;
    $("importBtn").onclick = () => $("csvFile").click();
    $("csvFile").onchange = (e) => { if (e.target.files[0]) importCSV(e.target.files[0]); e.target.value = ""; };
    $("deckSearch").oninput = (e) => ui.renderDeckLists(e.target.value);
    $("aiBtn").onclick = openAI; $("aiForm").addEventListener("submit", runAI);
    $("accountBtn").onclick = accountClick;
    $("authForm").addEventListener("submit", submitAuth);
    $("authSwitch").onclick = () => openAuth(authMode === "login" ? "register" : "login");
    $("authGuest").onclick = () => { try { localStorage.setItem("recallrocket:guest-ok", "1"); } catch {} $("authDialog").close(); };
    $("deleteAccountBtn").onclick = () => { $("deleteError").textContent = ""; $("deleteDialog").showModal(); };
    $("deleteForm").addEventListener("submit", submitDelete);
    $("mgrSave").onclick = saveManager; $("mgrDelete").onclick = deleteDeck;
    $("mgrAddCard").onclick = () => openCardDialog(managerDeckId);
    $("mgrExport").onclick = () => exportCSV(st.findDeck(managerDeckId));
    $("mgrCards").addEventListener("click", (e) => {
      const ed = e.target.closest("[data-edit-card]"), del = e.target.closest("[data-del-card]");
      if (ed) openCardDialog(managerDeckId, ed.dataset.editCard); else if (del) deleteCard(del.dataset.delCard);
    });
    document.addEventListener("click", (e) => {
      const study = e.target.closest("[data-study-deck]"), add = e.target.closest("[data-add-card]"), menu = e.target.closest("[data-deck-menu]");
      if (study) { navigate("study"); startSession(study.dataset.studyDeck); }
      else if (add) openCardDialog(add.dataset.addCard);
      else if (menu) openManager(menu.dataset.deckMenu);
    });
    document.addEventListener("keydown", (e) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName) || document.querySelector("dialog[open]")) return;
      if (currentView !== "study") return;
      if (e.code === "Space") { e.preventDefault(); flipCard(); }
      if (/^[0-5]$/.test(e.key)) rateCard(Number(e.key)); // rateCard explains if the card isn't flipped yet
    });
  }

  /* ---------------- boot ---------------- */
  async function init() {
    try { if (localStorage.getItem("recallrocket-dark") === "true") document.body.classList.add("dark"); } catch {}
    setupEvents();
    st.onChange(() => { ui.renderStatus(); queueRender(); });
    if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("/sw.js").catch(() => {});

    let user = null, reachable = false;
    try { const r = await api.me(); reachable = r.status === 200 || r.status === 401; if (r.ok) user = r.data.user; } catch { /* file:// or offline */ }
    if (user) await st.useUser(user);
    else {
      st.useGuest();
      let seen = false; try { seen = !!localStorage.getItem("recallrocket:guest-ok"); } catch {}
      if (reachable && !seen) openAuth("login");
    }
    renderAll();
    $("pageTitle").innerHTML = `${escapeHTML(ui.greeting())}, ${escapeHTML(ui.displayName())} <span>✦</span>`;
  }
  init();
})();
