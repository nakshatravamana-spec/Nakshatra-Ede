"use strict";
const path = require("path");
const { createApp } = require("./server/app");

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");

(async () => {
  const app = createApp({ dataDir: DATA_DIR });
  await app.init();
  app.server.listen(PORT, () => console.log(`🚀 RecallRocket running at http://localhost:${PORT}`));
  const stop = (sig) => { console.log(`${sig} received, shutting down…`); app.server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 5000).unref(); };
  process.on("SIGTERM", () => stop("SIGTERM")); process.on("SIGINT", () => stop("SIGINT"));
})().catch((e) => { console.error("Failed to start:", e); process.exit(1); });
