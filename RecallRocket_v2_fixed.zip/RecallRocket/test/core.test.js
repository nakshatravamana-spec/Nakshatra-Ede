"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const c = require("../public/js/core.js");

const card = (o = {}) => ({ easeFactor: 2.5, repetitions: 0, interval: 0, ...o });
const T = "2026-11-20";

test("SM-2: first success = 1 day, second = 6 days, third = round(6 × EF)", () => {
  let k = card();
  let r = c.sm2(5, k, T); assert.equal(r.interval, 1); assert.equal(r.repetitions, 1);
  k = { ...k, ...r };
  r = c.sm2(5, k, T); assert.equal(r.interval, 6); assert.equal(r.repetitions, 2);
  k = { ...k, ...r };
  r = c.sm2(5, k, T); assert.equal(r.interval, Math.round(6 * k.easeFactor)); assert.equal(r.repetitions, 3);
});
test("SM-2: grade 5 raises EF by 0.1, grade 4 leaves it, grade 3 lowers by 0.14", () => {
  assert.equal(c.sm2(5, card(), T).easeFactor, 2.6);
  assert.equal(c.sm2(4, card(), T).easeFactor, 2.5);
  assert.equal(c.sm2(3, card(), T).easeFactor, 2.36);
});
test("SM-2: lapse (grade <3) resets repetitions, schedules tomorrow and counts a lapse", () => {
  const r = c.sm2(2, card({ repetitions: 5, interval: 40, lapses: 1 }), T);
  assert.deepEqual([r.repetitions, r.interval, r.lapses, r.nextReviewDate], [0, 1, 2, "2026-11-21"]);
});
test("SM-2: EF never drops below 1.3", () => {
  let k = card({ easeFactor: 1.35 });
  for (let i = 0; i < 10; i++) k = { ...k, ...c.sm2(0, k, T) };
  assert.equal(k.easeFactor, 1.3);
});
test("SM-2: nextReviewDate is today + interval; does not mutate input", () => {
  const k = card({ repetitions: 1, interval: 1 }); const snap = JSON.stringify(k);
  assert.equal(c.sm2(4, k, T).nextReviewDate, "2026-11-26");
  assert.equal(JSON.stringify(k), snap);
});
test("SM-2: rejects invalid grades", () => {
  for (const g of [-1, 6, 2.5, "3", NaN, undefined]) assert.throws(() => c.sm2(g, card()), RangeError);
});
test("SM-2: tolerates corrupt numeric fields", () => {
  const r = c.sm2(4, { easeFactor: "abc", repetitions: null, interval: undefined }, T);
  assert.equal(r.interval, 1); assert.ok(Number.isFinite(r.easeFactor));
});

test("dates: addDays crosses month/year/leap boundaries", () => {
  assert.equal(c.addDays("2026-12-31", 1), "2027-01-01");
  assert.equal(c.addDays("2028-02-28", 1), "2028-02-29");
  assert.equal(c.addDays("2026-03-01", -1), "2026-02-28");
});
test("dates: isValidKey rejects impossible dates", () => {
  assert.ok(c.isValidKey("2026-02-28")); assert.ok(!c.isValidKey("2026-02-30")); assert.ok(!c.isValidKey("2026-2-3")); assert.ok(!c.isValidKey(20260101));
});

test("streak: consecutive days, still alive if only yesterday studied, broken after a gap", () => {
  assert.equal(c.calcStreak(["2026-11-18", "2026-11-19", "2026-11-20"], T), 3);
  assert.equal(c.calcStreak(["2026-11-18", "2026-11-19"], T), 2);
  assert.equal(c.calcStreak(["2026-11-17"], T), 0);
  assert.equal(c.calcStreak(["2026-11-15", "2026-11-19", "2026-11-20"], T), 2);
  assert.equal(c.calcStreak([], T), 0);
  assert.equal(c.calcStreak(["2026-11-20", "2026-11-20"], T), 1);
});

test("points + summarise derive totals from the review log", () => {
  const rs = [{ grade: 5, date: "2026-11-19" }, { grade: 3, date: "2026-11-20" }, { grade: 0, date: "2026-11-20" }];
  const s = c.summarise(rs, T);
  assert.deepEqual([s.points, s.reviewed, s.streak], [10 + 5 + 0, 3, 2]);
});

test("prioritise: most overdue first, ties keep original order", () => {
  const cards = [{ id: "a", nextReviewDate: "2026-11-20" }, { id: "b", nextReviewDate: "2026-11-10" }, { id: "c", nextReviewDate: "2026-11-20" }];
  assert.deepEqual(c.prioritise(cards, T).map((x) => x.id), ["b", "a", "c"]);
});
test("leech detection at 4 lapses", () => { assert.ok(c.isLeech({ lapses: 4 })); assert.ok(!c.isLeech({ lapses: 3 })); });
test("retentionByInterval buckets real history", () => {
  const out = c.retentionByInterval([{ prevInterval: 1, grade: 5 }, { prevInterval: 1, grade: 1 }, { prevInterval: 6, grade: 4 }]);
  assert.equal(out[0].rate, 50); assert.equal(out[2].rate, 100); assert.equal(out[4].rate, null);
});

test("validateState: accepts clean state and strips control chars / truncates", () => {
  const long = "x".repeat(1000);
  const r = c.validateState({ decks: [{ id: "d1", name: " Deck\u0000 ", color: "pink", cards: [{ id: "c1", question: long, answer: "A" }] }], reviews: [] }, "2030-01-01");
  assert.ok(r.ok); assert.equal(r.value.decks[0].name, "Deck"); assert.equal(r.value.decks[0].color, "violet");
  assert.equal(r.value.decks[0].cards[0].question.length, c.LIMITS.question);
});
test("validateState: rejects bad shapes", () => {
  const bad = [null, [], {}, { decks: [], reviews: "x" }, { decks: [{ id: "d", name: "", cards: [] }], reviews: [] },
    { decks: [{ id: "bad id!", name: "x", cards: [] }], reviews: [] },
    { decks: [{ id: "d", name: "x", cards: [] }, { id: "d", name: "y", cards: [] }], reviews: [] },
    { decks: [], reviews: [{ id: "r", cardId: "c", deckId: "d", grade: 9, date: "2026-11-20" }] },
    { decks: [], reviews: [{ id: "r", cardId: "c", deckId: "d", grade: 3, date: "2099-01-01" }] }];
  for (const b of bad) assert.equal(c.validateState(b, "2026-11-21").ok, false, JSON.stringify(b));
});
test("validateState: caps implausible daily review volume", () => {
  const reviews = Array.from({ length: c.LIMITS.reviewsPerDay + 1 }, (_, i) => ({ id: "r" + i, cardId: "c", deckId: "d", grade: 5, date: "2026-11-20" }));
  assert.equal(c.validateState({ decks: [], reviews }, "2026-11-21").ok, false);
});
test("validateState: points are recomputed from grade, never trusted", () => {
  const r = c.validateState({ decks: [], reviews: [{ id: "r", cardId: "c", deckId: "d", grade: 0, date: "2026-11-20", points: 9999 }] }, "2026-11-21");
  assert.equal(r.value.reviews[0].points, 0);
});

test("mergeStates: unions reviews, keeps newest card, keeps both sides' new decks", () => {
  const mk = (cards, id = "d1") => ({ id, name: "D", description: "", color: "blue", cards });
  const remote = { decks: [mk([{ id: "c1", lastReviewed: "2026-11-18", repetitions: 1 }])], reviews: [{ id: "r1" }] };
  const local = { decks: [mk([{ id: "c1", lastReviewed: "2026-11-20", repetitions: 2 }, { id: "c2" }]), mk([], "d2")], reviews: [{ id: "r1" }, { id: "r2" }] };
  const m = c.mergeStates(local, remote);
  assert.equal(m.reviews.length, 2); assert.equal(m.decks.length, 2);
  assert.equal(m.decks[0].cards.find((x) => x.id === "c1").repetitions, 2); assert.equal(m.decks[0].cards.length, 2);
});

test("CSV: quotes, embedded commas/newlines, CRLF, blank lines", () => {
  const rows = c.parseCSV('Deck,Question,Answer\r\nA,"What, exactly?","Line1\nLine2"\r\n\r\nB,"He said ""hi""",x');
  assert.deepEqual(rows, [["Deck", "Question", "Answer"], ["A", "What, exactly?", "Line1\nLine2"], ["B", 'He said "hi"', "x"]]);
});
test("CSV export neutralises formula injection", () => {
  assert.equal(c.csvCell("=HYPERLINK(1)"), `"'=HYPERLINK(1)"`);
  assert.equal(c.csvCell("@SUM(A1)"), `"'@SUM(A1)"`);
  assert.equal(c.csvCell('say "x"'), `"say ""x"""`);
  assert.equal(c.csvCell(null), `""`);
});
