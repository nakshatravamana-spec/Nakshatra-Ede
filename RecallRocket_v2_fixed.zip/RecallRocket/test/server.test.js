"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs"); const os = require("os"); const path = require("path");
const { createApp } = require("../server/app");
const { parseCards } = require("../server/ai");
const { Store } = require("../server/store");

const H = { "Content-Type": "application/json", "X-Requested-With": "RecallRocket" };
let clock = Date.parse("2026-11-20T12:00:00Z");

async function boot(opts = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "rr-"));
  const app = createApp({ dataDir: dir, now: () => clock, ...opts });
  await app.init();
  await new Promise((r) => app.server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, { body, cookie, headers } = {}) => {
    const res = await fetch(base + url, { method, headers: { ...H, ...(cookie && { Cookie: cookie }), ...headers }, body: body === undefined ? undefined : typeof body === "string" ? body : JSON.stringify(body) });
    const text = await res.text(); let data; try { data = JSON.parse(text); } catch { data = text; }
    return { status: res.status, data, headers: res.headers };
  };
  const signup = async (username, password = "correct-horse-1") => {
    const r = await call("POST", "/api/auth/register", { body: { username, password, displayName: username } });
    return { r, cookie: (r.headers.get("set-cookie") || "").split(";")[0] };
  };
  const close = () => new Promise((r) => { app.server.close(r); app.server.closeAllConnections?.(); });
  return { app, dir, base, call, signup, close };
}
const deck = (id = "d1", cards = [{ id: "c1", question: "Q", answer: "A" }]) => ({ id, name: "Deck " + id, description: "", color: "blue", cards });
const rev = (id, grade = 5, date = "2026-11-20") => ({ id, cardId: "c1", deckId: "d1", grade, date });

test("health endpoint + security headers", async () => {
  const s = await boot();
  const r = await s.call("GET", "/api/health");
  assert.equal(r.status, 200); assert.equal(r.data.ok, true);
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.match(r.headers.get("content-security-policy"), /frame-ancestors 'none'/);
  await s.close();
});

test("static: serves index, SPA fallback, blocks path traversal", async () => {
  const s = await boot();
  assert.equal((await s.call("GET", "/")).status, 200);
  assert.equal((await s.call("GET", "/some/client/route")).status, 200);
  assert.equal((await s.call("GET", "/nope.js")).status, 404);
  for (const p of ["/..%2f..%2fserver.js", "/%2e%2e/server.js", "/..%5cserver.js", "/%00.js"]) assert.notEqual((await s.call("GET", p)).status, 200, p);
  assert.equal((await s.call("GET", "/js/core.js")).status, 200);
  await s.close();
});

test("auth: register, session cookie flags, me, logout invalidates session", async () => {
  const s = await boot();
  const { r, cookie } = await s.signup("alice");
  assert.equal(r.status, 201);
  assert.match(r.headers.get("set-cookie"), /HttpOnly/); assert.match(r.headers.get("set-cookie"), /SameSite=Strict/);
  assert.equal(r.data.user.username, "alice"); assert.equal(r.data.user.hash, undefined);
  assert.equal((await s.call("GET", "/api/auth/me", { cookie })).data.user.name, "alice");
  await s.call("POST", "/api/auth/logout", { cookie, body: {} });
  assert.equal((await s.call("GET", "/api/auth/me", { cookie })).status, 401);
  await s.close();
});

test("auth: stored passwords are hashed, duplicates rejected, weak input rejected", async () => {
  const s = await boot();
  await s.signup("bob", "supersecret1");
  const raw = fs.readFileSync(path.join(s.dir, "users-index.json"), "utf8");
  assert.ok(!raw.includes("supersecret1")); assert.match(raw, /"salt"/);
  assert.equal((await s.signup("BOB", "supersecret1")).r.status, 409);
  assert.equal((await s.call("POST", "/api/auth/register", { body: { username: "x", password: "supersecret1" } })).status, 400);
  assert.equal((await s.call("POST", "/api/auth/register", { body: { username: "carol", password: "short" } })).status, 400);
  assert.equal((await s.call("POST", "/api/auth/register", { body: { username: "bad name!", password: "supersecret1" } })).status, 400);
  await s.close();
});

test("auth: login success/failure, no user enumeration, rate limiting", async () => {
  const s = await boot();
  await s.signup("dave", "supersecret1");
  assert.equal((await s.call("POST", "/api/auth/login", { body: { username: "dave", password: "supersecret1" } })).status, 200);
  const wrong = await s.call("POST", "/api/auth/login", { body: { username: "dave", password: "nope-nope-1" } });
  const ghost = await s.call("POST", "/api/auth/login", { body: { username: "ghost", password: "nope-nope-1" } });
  assert.equal(wrong.status, 401); assert.deepEqual(wrong.data, ghost.data);
  let last; for (let i = 0; i < 12; i++) last = await s.call("POST", "/api/auth/login", { body: { username: "dave", password: "bad-bad-bad" } });
  assert.equal(last.status, 429);
  await s.close();
});

test("security: state-changing requests need CSRF header and same origin", async () => {
  const s = await boot();
  const { cookie } = await s.signup("erin");
  const noHeader = await fetch(s.base + "/api/state", { method: "PUT", headers: { "Content-Type": "application/json", Cookie: cookie }, body: "{}" });
  assert.equal(noHeader.status, 403);
  const evil = await s.call("PUT", "/api/state", { cookie, body: { decks: [], reviews: [], baseRev: 0 }, headers: { Origin: "https://evil.example" } });
  assert.equal(evil.status, 403);
  await s.close();
});

test("api: unauthenticated access is rejected", async () => {
  const s = await boot();
  for (const [m, u] of [["GET", "/api/state"], ["PUT", "/api/state"], ["GET", "/api/leaderboard"], ["POST", "/api/ai/generate"], ["DELETE", "/api/account"]]) {
    assert.equal((await s.call(m, u, { body: m === "GET" ? undefined : {} })).status, 401, u);
  }
  await s.close();
});

test("api: malformed JSON → 400, wrong content type → 415, oversized body → 413, unknown route → 404 (never HTML/stack)", async () => {
  const s = await boot();
  const { cookie } = await s.signup("frank");
  const bad = await s.call("PUT", "/api/state", { cookie, body: "{not json" });
  assert.equal(bad.status, 400); assert.equal(typeof bad.data.error, "string");
  assert.equal((await s.call("PUT", "/api/state", { cookie, body: "x", headers: { "Content-Type": "text/plain" } })).status, 415);
  assert.equal((await s.call("PUT", "/api/state", { cookie, body: JSON.stringify({ pad: "x".repeat(3 * 1024 * 1024) }) })).status, 413);
  const nf = await s.call("GET", "/api/zzz"); assert.equal(nf.status, 404); assert.ok(!String(nf.data.error).includes("at "));
  await s.close();
});

test("state: round-trips, validates deeply, isolates users", async () => {
  const s = await boot();
  const a = await s.signup("ann"), b = await s.signup("ben");
  const put = await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [deck()], reviews: [rev("r1")], baseRev: 0 } });
  assert.deepEqual([put.status, put.data.rev], [200, 1]);
  assert.equal((await s.call("GET", "/api/state", { cookie: a.cookie })).data.decks[0].id, "d1");
  assert.equal((await s.call("GET", "/api/state", { cookie: b.cookie })).data.decks.length, 0);
  const deepBad = await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [{ id: "d", name: "x", cards: [{ id: "c", question: "", answer: "A" }, 42] }], reviews: [], baseRev: 1 } });
  assert.equal(deepBad.status, 200); // invalid cards are dropped, not stored
  assert.equal((await s.call("GET", "/api/state", { cookie: a.cookie })).data.decks[0].cards.length, 0);
  assert.equal((await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [{ id: "d", name: "", cards: [] }], reviews: [], baseRev: 2 } })).status, 400);
  assert.equal((await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [], reviews: [] } })).status, 400);
  await s.close();
});

test("state: optimistic concurrency returns 409 with the server copy", async () => {
  const s = await boot();
  const { cookie } = await s.signup("gina");
  await s.call("PUT", "/api/state", { cookie, body: { decks: [deck()], reviews: [], baseRev: 0 } });
  const stale = await s.call("PUT", "/api/state", { cookie, body: { decks: [], reviews: [], baseRev: 0 } });
  assert.equal(stale.status, 409); assert.equal(stale.data.rev, 1); assert.equal(stale.data.decks.length, 1);
  await s.close();
});

test("state: 25 concurrent writes with the same baseRev → exactly one wins (no lost updates, valid JSON on disk)", async () => {
  const s = await boot();
  const { cookie } = await s.signup("hank");
  const results = await Promise.all(Array.from({ length: 25 }, (_, i) => s.call("PUT", "/api/state", { cookie, body: { decks: [deck("d" + i)], reviews: [], baseRev: 0 } })));
  assert.equal(results.filter((r) => r.status === 200).length, 1);
  assert.equal(results.filter((r) => r.status === 409).length, 24);
  const files = fs.readdirSync(path.join(s.dir, "users"));
  assert.ok(files.every((f) => f.endsWith(".json")), "no temp files left: " + files);
  for (const f of files) JSON.parse(fs.readFileSync(path.join(s.dir, "users", f), "utf8"));
  await s.close();
});

test("leaderboard: points are derived server-side; forged totals and future dates are ignored/rejected", async () => {
  const s = await boot();
  const a = await s.signup("lee"), b = await s.signup("mia");
  await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [deck()], reviews: [rev("r1", 5), rev("r2", 3, "2026-11-19")], baseRev: 0, points: 999999, profile: { points: 999999 } } });
  await s.call("PUT", "/api/state", { cookie: b.cookie, body: { decks: [deck()], reviews: [rev("r3", 0)], baseRev: 0 } });
  const lb = (await s.call("GET", "/api/leaderboard", { cookie: a.cookie })).data;
  assert.equal(lb.total, 2); assert.equal(lb.entries[0].name, "lee"); assert.equal(lb.entries[0].points, 15);
  assert.equal(lb.entries[0].streak, 2); assert.equal(lb.me.rank, 1); assert.equal(lb.entries[1].points, 0);
  assert.equal(lb.entries[0].hash, undefined); assert.equal(lb.entries[0].salt, undefined);
  const future = await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [deck()], reviews: [rev("r9", 5, "2030-01-01")], baseRev: 1 } });
  assert.equal(future.status, 400);
  await s.close();
});

test("leaderboard: streak expires when the user stops studying", async () => {
  const s = await boot();
  const a = await s.signup("ned");
  await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [deck()], reviews: [rev("r1")], baseRev: 0 } });
  assert.equal((await s.call("GET", "/api/leaderboard", { cookie: a.cookie })).data.me.streak, 1);
  clock += 5 * 86400000;
  assert.equal((await s.call("GET", "/api/leaderboard", { cookie: a.cookie })).data.me.streak, 0);
  clock -= 5 * 86400000;
  await s.close();
});

test("account deletion requires the password and wipes data + sessions", async () => {
  const s = await boot();
  const a = await s.signup("oli", "supersecret1");
  await s.call("PUT", "/api/state", { cookie: a.cookie, body: { decks: [deck()], reviews: [], baseRev: 0 } });
  assert.equal((await s.call("DELETE", "/api/account", { cookie: a.cookie, body: { password: "wrong-wrong" } })).status, 403);
  assert.equal((await s.call("DELETE", "/api/account", { cookie: a.cookie, body: { password: "supersecret1" } })).status, 200);
  assert.equal((await s.call("GET", "/api/auth/me", { cookie: a.cookie })).status, 401);
  assert.equal(fs.readdirSync(path.join(s.dir, "users")).length, 0);
  await s.close();
});

test("AI: disabled without key (503); parses/limits model output; maps upstream failure to 502", async () => {
  let s = await boot({ env: {} });
  let a = await s.signup("pat");
  assert.equal((await s.call("POST", "/api/ai/generate", { cookie: a.cookie, body: { topic: "Photosynthesis" } })).status, 503);
  await s.close();

  const ok = async () => ({ ok: true, json: async () => ({ content: [{ type: "text", text: '```json\n[{"question":"Q1","answer":"A1"},{"question":"","answer":"x"},{"question":"Q2","answer":"A2"}]\n```' }] }) });
  s = await boot({ env: { ANTHROPIC_API_KEY: "k" }, fetchImpl: ok }); a = await s.signup("quinn");
  const r = await s.call("POST", "/api/ai/generate", { cookie: a.cookie, body: { topic: "Photosynthesis", count: 5 } });
  assert.equal(r.status, 200); assert.equal(r.data.cards.length, 2);
  assert.equal((await s.call("POST", "/api/ai/generate", { cookie: a.cookie, body: { topic: "x" } })).status, 400);
  await s.close();

  s = await boot({ env: { ANTHROPIC_API_KEY: "k" }, fetchImpl: async () => ({ ok: false, status: 500 }) }); a = await s.signup("rae");
  assert.equal((await s.call("POST", "/api/ai/generate", { cookie: a.cookie, body: { topic: "Photosynthesis" } })).status, 502);
  await s.close();
});
test("AI parseCards rejects garbage", () => { assert.throws(() => parseCards("sorry, no", 3)); assert.throws(() => parseCards("[]", 3)); });

test("store: atomic write leaves no temp file; corrupt file is quarantined, never silently replaced by empty data", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "rr-store-"));
  const st = new Store(dir); await st.init();
  await st.write("a", { v: 1 });
  assert.deepEqual(fs.readdirSync(dir).filter((f) => f.includes(".tmp")), []);
  fs.writeFileSync(path.join(dir, "b.json"), "{ truncated");
  await assert.rejects(() => st.read("b", {}), /corrupt/);
  assert.ok(fs.readdirSync(dir).some((f) => f.startsWith("b.json.corrupt-")));
  assert.throws(() => st.file("../etc/passwd"));
});
