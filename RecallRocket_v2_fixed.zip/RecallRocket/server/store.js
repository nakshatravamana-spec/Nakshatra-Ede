"use strict";
/*
 * File-backed store with:
 *  - one JSON file per document (so users never contend for one global file),
 *  - atomic writes (write temp file → fsync → rename), so a crash can't leave a half-written file,
 *  - a per-key async mutex, so concurrent read-modify-write cycles on one document are serialised,
 *  - corruption is surfaced as an error and the bad file is quarantined — it is never silently replaced by an empty DB.
 */
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

class Store {
  constructor(dir) { this.dir = dir; this.locks = new Map(); this.cache = new Map(); }

  async init() { await fsp.mkdir(path.join(this.dir, "users"), { recursive: true }); }
  file(key) {
    if (!/^[\w.-]+(\/[\w.-]+)*$/.test(key) || key.includes("..")) throw new Error("Invalid store key");
    return path.join(this.dir, key + ".json");
  }

  async read(key, fallback) {
    if (this.cache.has(key)) return structuredClone(this.cache.get(key));
    let text;
    try { text = await fsp.readFile(this.file(key), "utf8"); }
    catch (e) { if (e.code === "ENOENT") return structuredClone(fallback); throw e; }
    try { const v = JSON.parse(text); this.cache.set(key, v); return structuredClone(v); }
    catch {
      await fsp.rename(this.file(key), this.file(key) + `.corrupt-${Date.now()}`).catch(() => {});
      throw new Error(`Stored data for "${key}" was corrupt and has been quarantined.`);
    }
  }

  async write(key, value) {
    const target = this.file(key), tmp = `${target}.${process.pid}.${Date.now()}.tmp`;
    await fsp.mkdir(path.dirname(target), { recursive: true });
    const fh = await fsp.open(tmp, "w");
    try { await fh.writeFile(JSON.stringify(value)); await fh.sync(); } finally { await fh.close(); }
    await fsp.rename(tmp, target);
    this.cache.set(key, structuredClone(value));
  }

  /** Serialised read-modify-write. `fn(current)` returns the new value (or undefined to leave unchanged) and may return extra via {value, result}. */
  async update(key, fallback, fn) {
    const prev = this.locks.get(key) || Promise.resolve();
    let release; const gate = new Promise((r) => (release = r));
    this.locks.set(key, prev.then(() => gate));
    await prev;
    try {
      const current = await this.read(key, fallback);
      const out = await fn(current);
      if (out && out.value !== undefined) await this.write(key, out.value);
      return out ? out.result : undefined;
    } finally {
      release();
    }
  }

  async remove(key) { this.cache.delete(key); await fsp.rm(this.file(key), { force: true }); }
}

module.exports = { Store };
