"use strict";
/* Accounts + sessions. Passwords: scrypt with per-user salt. Sessions: random 256-bit tokens, only their SHA-256 is stored. */
const crypto = require("crypto");
const { promisify } = require("util");
const scrypt = promisify(crypto.scrypt);
const { HttpError } = require("./http");
const core = require("../public/js/core.js");

const SESSION_TTL_MS = 14 * 24 * 3600 * 1000;
const USERNAME_RE = /^[a-z0-9_]{3,24}$/;
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");

async function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const key = await scrypt(password, salt, 64);
  return { salt, hash: key.toString("hex") };
}
async function verifyPassword(password, { salt, hash }) {
  const key = await scrypt(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return key.length === expected.length && crypto.timingSafeEqual(key, expected);
}

function validateCredentials({ username, password, displayName }, { requireName = false } = {}) {
  const u = String(username ?? "").trim().toLowerCase();
  if (!USERNAME_RE.test(u)) throw new HttpError(400, "Username must be 3–24 characters: lowercase letters, digits or underscore.");
  if (typeof password !== "string" || password.length < 8 || password.length > 128) throw new HttpError(400, "Password must be 8–128 characters.");
  const name = core.clean(displayName || username, 30);
  if (requireName && !name) throw new HttpError(400, "Display name is required.");
  return { username: u, password, displayName: name || u };
}

function createAuth({ store, now = Date.now }) {
  const DUMMY = hashPassword("dummy-password-for-timing");

  async function register(body) {
    const { username, password, displayName } = validateCredentials(body);
    const { salt, hash } = await hashPassword(password);
    const id = crypto.randomUUID();
    const result = await store.update("users-index", { users: {} }, (idx) => {
      if (Object.values(idx.users).some((u) => u.username === username)) return { result: null };
      idx.users[id] = { id, username, displayName, salt, hash, createdAt: new Date(now()).toISOString(), points: 0, streak: 0, reviewed: 0, lastStudyDate: null };
      return { value: idx, result: idx.users[id] };
    });
    if (!result) throw new HttpError(409, "That username is already taken.");
    return result;
  }

  async function login(body) {
    const username = String(body?.username ?? "").trim().toLowerCase(), password = body?.password;
    if (typeof password !== "string" || password.length > 128) throw new HttpError(400, "Invalid credentials.");
    const idx = await store.read("users-index", { users: {} });
    const user = Object.values(idx.users).find((u) => u.username === username);
    const ok = user ? await verifyPassword(password, user) : (await verifyPassword(password, await DUMMY), false);
    if (!ok) throw new HttpError(401, "Incorrect username or password.");
    return user;
  }

  async function createSession(userId) {
    const token = crypto.randomBytes(32).toString("base64url");
    await store.update("sessions", { s: {} }, (db) => {
      const t = now();
      for (const [k, v] of Object.entries(db.s)) if (v.exp <= t) delete db.s[k];
      db.s[sha(token)] = { userId, exp: t + SESSION_TTL_MS };
      return { value: db };
    });
    return token;
  }
  async function userFromToken(token) {
    if (!token) return null;
    const db = await store.read("sessions", { s: {} });
    const s = db.s[sha(token)];
    if (!s || s.exp <= now()) return null;
    const idx = await store.read("users-index", { users: {} });
    return idx.users[s.userId] || null;
  }
  async function destroySession(token) {
    if (!token) return;
    await store.update("sessions", { s: {} }, (db) => { delete db.s[sha(token)]; return { value: db }; });
  }
  async function destroyAllSessions(userId) {
    await store.update("sessions", { s: {} }, (db) => { for (const [k, v] of Object.entries(db.s)) if (v.userId === userId) delete db.s[k]; return { value: db }; });
  }

  return { register, login, createSession, userFromToken, destroySession, destroyAllSessions, verifyPassword, SESSION_TTL_MS };
}

module.exports = { createAuth, hashPassword, verifyPassword, validateCredentials };
