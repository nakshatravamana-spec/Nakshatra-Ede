"use strict";
const http = require("http");
const fs = require("fs/promises");
const path = require("path");
const { Store } = require("./store");
const { createAuth } = require("./auth");
const { generateCards } = require("./ai");
const { HttpError, json, send, readJson, parseCookies, cookie, createLimiter } = require("./http");
const core = require("../public/js/core.js");

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json" };
const utcKey = (ms) => new Date(ms).toISOString().slice(0, 10);
const EMPTY_DOC = { decks: [], reviews: [], rev: 0 };

function createApp({ dataDir, publicDir = path.join(__dirname, "..", "public"), now = Date.now, fetchImpl, env = process.env } = {}) {
  const store = new Store(dataDir);
  const auth = createAuth({ store, now });
  const secure = env.COOKIE_SECURE === "true" || env.NODE_ENV === "production";
  const ipLimit = createLimiter({ windowMs: 60_000, max: 300, now });
  const authLimit = createLimiter({ windowMs: 60_000, max: 10, now });
  const aiLimit = createLimiter({ windowMs: 60_000, max: 5, now });
  const sweeper = setInterval(() => { ipLimit.sweep(); authLimit.sweep(); aiLimit.sweep(); }, 60_000); sweeper.unref();

  const publicUser = (u) => ({ id: u.id, username: u.username, name: u.displayName });
  const effectiveStreak = (u) => (u.lastStudyDate && core.daysBetween(u.lastStudyDate, utcKey(now())) <= 2 ? u.streak : 0);

  async function requireUser(req) {
    const user = await auth.userFromToken(parseCookies(req.headers.cookie).rr_session);
    if (!user) throw new HttpError(401, "Please sign in.");
    return user;
  }
  function csrfGuard(req) {
    if (req.headers["x-requested-with"] !== "RecallRocket") throw new HttpError(403, "Missing required header.");
    const origin = req.headers.origin;
    if (origin) { let host; try { host = new URL(origin).host; } catch { throw new HttpError(403, "Bad origin."); } if (host !== req.headers.host) throw new HttpError(403, "Cross-origin request blocked."); }
  }
  const startSession = async (res, user, status = 200) => {
    const token = await auth.createSession(user.id);
    json(res, status, { user: publicUser(user) }, { "Set-Cookie": cookie("rr_session", token, { maxAge: auth.SESSION_TTL_MS / 1000, secure }) });
  };

  async function saveState(user, body) {
    const maxDate = core.addDays(utcKey(now()), 1);
    const v = core.validateState(body, maxDate);
    if (!v.ok) throw new HttpError(400, v.error);
    if (!Number.isInteger(body.baseRev) || body.baseRev < 0) throw new HttpError(400, "baseRev is required.");
    const outcome = await store.update(`users/${user.id}`, EMPTY_DOC, (doc) => {
      if (doc.rev !== body.baseRev) return { result: { conflict: true, doc } };
      const next = { decks: v.value.decks, reviews: v.value.reviews, rev: doc.rev + 1, updatedAt: new Date(now()).toISOString() };
      return { value: next, result: { conflict: false, doc: next } };
    });
    if (outcome.conflict) return outcome;
    const s = core.summarise(outcome.doc.reviews, outcome.doc.reviews.map((r) => r.date).sort().pop() || utcKey(now()));
    await store.update("users-index", { users: {} }, (idx) => {
      const u = idx.users[user.id]; if (!u) return;
      Object.assign(u, { points: s.points, reviewed: s.reviewed, streak: s.streak, lastStudyDate: s.studyDates[s.studyDates.length - 1] || null });
      return { value: idx };
    });
    return outcome;
  }

  async function api(req, res, url) {
    const ip = req.socket.remoteAddress || "?";
    if (!ipLimit.take(ip)) throw new HttpError(429, "Too many requests. Slow down.");
    const route = `${req.method} ${url.pathname}`;
    if (req.method !== "GET" && req.method !== "HEAD") csrfGuard(req);

    switch (route) {
      case "GET /api/health": return json(res, 200, { ok: true, app: "RecallRocket", uptime: Math.round(process.uptime()) });

      case "POST /api/auth/register": {
        if (!authLimit.take(`reg:${ip}`)) throw new HttpError(429, "Too many attempts. Try again in a minute.");
        const user = await auth.register(await readJson(req, 10_000));
        return startSession(res, user, 201);
      }
      case "POST /api/auth/login": {
        const body = await readJson(req, 10_000);
        if (!authLimit.take(`login:${ip}:${String(body?.username).toLowerCase()}`)) throw new HttpError(429, "Too many attempts. Try again in a minute.");
        return startSession(res, await auth.login(body));
      }
      case "POST /api/auth/logout":
        await auth.destroySession(parseCookies(req.headers.cookie).rr_session);
        return json(res, 200, { ok: true }, { "Set-Cookie": cookie("rr_session", "", { maxAge: 0, secure }) });
      case "GET /api/auth/me": return json(res, 200, { user: publicUser(await requireUser(req)) });

      case "DELETE /api/account": {
        const user = await requireUser(req);
        const body = await readJson(req, 10_000);
        if (typeof body?.password !== "string" || !(await auth.verifyPassword(body.password, user))) throw new HttpError(403, "Password incorrect.");
        await auth.destroyAllSessions(user.id);
        await store.update("users-index", { users: {} }, (idx) => { delete idx.users[user.id]; return { value: idx }; });
        await store.remove(`users/${user.id}`);
        return json(res, 200, { ok: true }, { "Set-Cookie": cookie("rr_session", "", { maxAge: 0, secure }) });
      }

      case "GET /api/state": {
        const user = await requireUser(req);
        const doc = await store.read(`users/${user.id}`, EMPTY_DOC);
        return json(res, 200, { decks: doc.decks, reviews: doc.reviews, rev: doc.rev, user: publicUser(user) });
      }
      case "PUT /api/state": {
        const user = await requireUser(req);
        const out = await saveState(user, await readJson(req));
        if (out.conflict) return json(res, 409, { error: "State changed on another device.", decks: out.doc.decks, reviews: out.doc.reviews, rev: out.doc.rev });
        return json(res, 200, { ok: true, rev: out.doc.rev });
      }

      case "GET /api/leaderboard": {
        const me = await requireUser(req);
        const idx = await store.read("users-index", { users: {} });
        const ranked = Object.values(idx.users)
          .map((u) => ({ id: u.id, name: u.displayName, points: u.points || 0, streak: effectiveStreak(u), reviewed: u.reviewed || 0 }))
          .sort((a, b) => b.points - a.points || b.reviewed - a.reviewed || a.name.localeCompare(b.name))
          .map((u, i) => ({ ...u, rank: i + 1, isMe: u.id === me.id }));
        return json(res, 200, { total: ranked.length, entries: ranked.slice(0, 25), me: ranked.find((u) => u.isMe) });
      }

      case "POST /api/ai/generate": {
        const user = await requireUser(req);
        if (!aiLimit.take(`ai:${user.id}`)) throw new HttpError(429, "AI generation limit reached. Try again in a minute.");
        const body = await readJson(req, 5_000);
        return json(res, 200, { cards: await generateCards({ topic: body?.topic, count: body?.count, env, fetchImpl }) });
      }
      default:
        if (url.pathname.startsWith("/api/")) throw new HttpError(404, "Unknown API route.");
    }
  }

  async function serveStatic(req, res, pathname) {
    if (req.method !== "GET" && req.method !== "HEAD") throw new HttpError(405, "Method not allowed.");
    let rel;
    try { rel = decodeURIComponent(pathname); } catch { throw new HttpError(400, "Bad path."); }
    if (rel.includes("\0")) throw new HttpError(400, "Bad path.");
    if (rel === "/" || !path.extname(rel)) rel = "/index.html";
    const file = path.normalize(path.join(publicDir, rel));
    if (file !== publicDir && !file.startsWith(publicDir + path.sep)) throw new HttpError(404, "Not found.");
    let data;
    try { data = await fs.readFile(file); } catch { throw new HttpError(404, "Not found."); }
    send(res, 200, req.method === "HEAD" ? "" : data, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache" });
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost");
      if (url.pathname.startsWith("/api/")) await api(req, res, url); else await serveStatic(req, res, url.pathname);
    } catch (e) {
      if (res.headersSent) return res.end();
      if (e instanceof HttpError) return json(res, e.status, { error: e.message });
      console.error("Unhandled error:", e);
      json(res, 500, { error: "Internal server error." });
    }
  });
  server.requestTimeout = 30_000; server.headersTimeout = 15_000; server.keepAliveTimeout = 5_000;
  server.on("close", () => clearInterval(sweeper));
  return { server, store, init: () => store.init() };
}

module.exports = { createApp };
