"use strict";
/* Small HTTP helpers: JSON replies, bounded body reader, cookies, security headers, rate limiter. */

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  "Cross-Origin-Opener-Policy": "same-origin",
  "Content-Security-Policy": [
    "default-src 'self'",
    "script-src 'self' https://cdn.jsdelivr.net",
    "style-src 'self' https://fonts.googleapis.com",
    "font-src https://fonts.gstatic.com",
    "img-src 'self' data:",
    "connect-src 'self' https://cdn.jsdelivr.net https://fonts.googleapis.com https://fonts.gstatic.com",
    "worker-src 'self'",
    "object-src 'none'",
    "base-uri 'none'",
    "frame-ancestors 'none'",
    "form-action 'self'",
  ].join("; "),
};

function send(res, status, body, headers = {}) {
  const payload = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  const type = typeof body === "string" || Buffer.isBuffer(body) ? undefined : "application/json; charset=utf-8";
  res.writeHead(status, { ...SECURITY_HEADERS, ...(type && { "Content-Type": type }), "Cache-Control": "no-store", ...headers });
  res.end(payload);
}
const json = (res, status, body, headers) => send(res, status, body, headers);

async function readJson(req, limit = 2 * 1024 * 1024) {
  const type = (req.headers["content-type"] || "").split(";")[0].trim();
  if (type !== "application/json") throw new HttpError(415, "Content-Type must be application/json.");
  const chunks = []; let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new HttpError(413, "Request body too large.");
    chunks.push(chunk);
  }
  try { const v = JSON.parse(Buffer.concat(chunks).toString("utf8") || "null"); return v; }
  catch { throw new HttpError(400, "Malformed JSON."); }
}

function parseCookies(header = "") {
  const out = {};
  for (const part of header.split(";")) {
    const i = part.indexOf("="); if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function cookie(name, value, { maxAge, secure } = {}) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict${secure ? "; Secure" : ""}${maxAge !== undefined ? `; Max-Age=${maxAge}` : ""}`;
}

/** Fixed-window in-memory limiter. Returns true if the call is allowed. */
function createLimiter({ windowMs, max, now = Date.now }) {
  const hits = new Map();
  return {
    take(key) {
      const t = now(), e = hits.get(key);
      if (!e || e.reset <= t) { hits.set(key, { n: 1, reset: t + windowMs }); return true; }
      return ++e.n <= max;
    },
    sweep() { const t = now(); for (const [k, e] of hits) if (e.reset <= t) hits.delete(k); },
  };
}

module.exports = { HttpError, SECURITY_HEADERS, send, json, readJson, parseCookies, cookie, createLimiter };
