# RecallRocket — MemoryMint Marathon

A spaced-repetition flashcard app: vanilla JS front end, dependency-free Node.js back end, SM-2 scheduling,
real accounts and a server-verified campus leaderboard.

## Quick start
```bash
node -v        # 18 or newer
npm start      # no npm install needed: zero runtime dependencies
# open http://localhost:3000
npm test       # 38 unit/integration tests (node:test) — no network needed
```
Opening `public/index.html` directly (file://) still works in **guest mode** (localStorage only).

| Env var | Purpose | Default |
|---|---|---|
| `PORT` | listen port | `3000` |
| `DATA_DIR` | where JSON data lives | `./data` |
| `ANTHROPIC_API_KEY` | enables AI card generation (server-side only) | unset → feature returns 503 |
| `ANTHROPIC_MODEL` | model for AI generation | `claude-sonnet-5-5` |
| `NODE_ENV=production` / `COOKIE_SECURE=true` | adds `Secure` flag to the session cookie (use behind HTTPS) | off |

## Features
- **SM-2** (grades 0–5): 1 day → 6 days → `round(interval × EF)`; EF floor 1.3; lapses reset repetitions. Overdue cards are studied first; cards forgotten 4+ times are flagged as *leeches*.
- 3D flip card, Space to flip, keys 0–5 to rate.
- Decks and cards: create / edit / delete, search, CSV import (size/row caps, de-duplication) and export (formula-injection safe), JSON backup.
- Streaks and points, **derived from the review log**, not stored as editable counters.
- **Accounts** (register / login / logout / delete), per-user data, **live leaderboard** computed server-side.
- Insights: 7-day activity, illustrative forgetting curve, **your real recall rate by interval**, leech list (Chart.js, degrades gracefully if the CDN is unreachable).
- **AI card generation** through a server endpoint (key never reaches the browser).
- Local-first + service worker: the app shell loads and reviews work offline; changes sync when back online.
- Dark mode, responsive layout, keyboard-accessible dialogs, reduced-motion support.

## Architecture
```
public/js/core.js   pure domain logic (SM-2, dates, streaks, validation, CSV, merge) — shared by browser AND server
public/js/api.js    fetch wrapper
public/js/state.js  client store: local-first persistence, debounced sync, conflict merge
public/js/ui.js     rendering only (every dynamic string escaped)
public/js/app.js    controller / event wiring
public/sw.js        offline cache
server.js           entry point (graceful shutdown)
server/app.js       routes, static files, rate limits, CSRF guard
server/auth.js      scrypt password hashing, hashed session tokens
server/store.js     per-document JSON store: atomic writes + per-key mutex + corruption quarantine
server/ai.js        server-side LLM call with output validation
test/               core.test.js, server.test.js
```
Because `core.js` is shared, the server re-validates everything with the *same* rules the client uses.

### API
| Method & path | Auth | Notes |
|---|---|---|
| `POST /api/auth/register` · `/login` · `/logout` | – | 10 attempts/min/IP (+username) |
| `GET /api/auth/me` | ✔ | |
| `GET /api/state` | ✔ | `{decks, reviews, rev}` |
| `PUT /api/state` | ✔ | body `{decks, reviews, baseRev}`; **409** + current copy if `baseRev` is stale |
| `GET /api/leaderboard` | ✔ | top 25 + your rank |
| `POST /api/ai/generate` | ✔ | 5 req/min/user |
| `DELETE /api/account` | ✔ | needs password |
| `GET /api/health` | – | |

## Design decisions
- **Scalability.** The original rewrote one global `data.json` on every sync. Now each user has their own file, writes are atomic (temp file → fsync → rename), serialised per user, and guarded by optimistic concurrency (`rev`). Concurrent writers can no longer silently overwrite each other (tested with 25 simultaneous writes). The leaderboard reads a small index, not every user's data.
- **Integrity.** The server never trusts client totals. Points, reviewed-count and streak are recomputed from the review log; each review is validated (grade 0–5, real date, not in the future, ≤1000/day); card/deck text is length-limited and stripped of control characters.
- **Security.** scrypt-hashed passwords; random 256-bit session tokens stored only as SHA-256; `HttpOnly` + `SameSite=Strict` cookie; CSRF header + Origin check; strict CSP, `X-Frame-Options`, `nosniff`; request-size, rate and timeout limits; path-traversal-safe static server; constant-work login to avoid user enumeration; no stack traces in errors.
- **Time zones.** Dates are local calendar days (the old version mixed UTC and local time, which mislabelled days for users east of UTC). The server accepts review dates up to UTC-today + 1 day so any time zone works.
- **SM-2 note.** Ease factor is updated on every grade including failures (the common Wikipedia/Anki-style reading). The original paper leaves EF unchanged on a failed review; change one line in `core.sm2` if you prefer that.

## Known limitations (honest)
- Storage is JSON files. That is appropriate for a campus-scale demo (hundreds of users); for thousands of concurrent users, replace `server/store.js` with SQLite/Postgres — the rest of the server only talks to the `Store` interface.
- Rate limiting is in-memory (per process). Run behind a reverse proxy / shared limiter for multi-instance deployments.
- Merge after a conflict is a union: a deletion made on a stale device can reappear.
- A determined user can still fabricate plausible reviews for cards they own; the validation bounds the damage (daily cap, no future dates) but cannot prove a human studied. Fully authoritative grading would require the server to schedule cards itself.
- Chart.js and fonts load from CDNs (the service worker caches them after first load). Vendor them for fully air-gapped use.
- No password reset / email verification (no mail service in scope).

## CSV format
Required columns `Question`, `Answer`; optional `Deck`. Aliases `front/back/prompt/response` accepted. Max 1 MB / 2000 rows.
```csv
Deck,Question,Answer
Algorithms,What is Big-O?,A way to describe algorithm growth
```

## Demo script (≈3 minutes)
1. Register → 3 seeded decks appear and sync. 2. Study: flip with Space, rate 5 → "1 day" (SM-2). 3. Rate again later → 6 days.
4. Leaderboard: points/streak come from the server. 5. Decks → ··· → edit/delete cards. 6. Insights → real recall chart + leeches.
7. Toggle airplane mode: keep reviewing; reconnect and watch it sync. 8. `npm test`.
