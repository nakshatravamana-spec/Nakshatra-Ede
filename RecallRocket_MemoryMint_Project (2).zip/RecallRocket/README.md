# RecallRocket — MemoryMint Marathon

A responsive spaced-repetition flashcard application built with HTML, CSS, vanilla JavaScript, Node.js and Express.

## Features
- SuperMemo-2 (SM-2) scheduling with grades 0–5, adaptive ease factor and 1.3 minimum EF.
- 3D flashcard flip with Space shortcut and 0–5 keyboard ratings.
- Due-today review queue and per-deck study.
- Create/edit/delete decks, add cards, search decks.
- Daily streak tracking, memory points and cohort leaderboard.
- Activity chart and illustrative forgetting/retention curve (Chart.js).
- CSV import/export and JSON backup export.
- Dark mode, responsive mobile layout and localStorage persistence.
- Optional Express JSON persistence for shared-server demos.

## Run locally
1. Install Node.js 18 or later.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

You can also open `public/index.html` directly. In that mode, the app uses browser localStorage; the Express API sync is available when run through Node.

## CSV import format
Required columns: `Question`, `Answer`. Optional column: `Deck`.

Example:
```csv
Deck,Question,Answer
Algorithms,What is Big-O?,A way to describe algorithm growth
```

## Demo flow for presentation
1. Open Overview and show the three seeded decks.
2. Open Study session. The sample cards are initially due today.
3. Flip the QuickSort card with Space.
4. Rate it 5 - Perfect. The SM-2 result is interval 1 day for the first successful review, then 6 days after the second successful review, and then grows by the ease factor.
5. Show updated points, streak, and review activity.
6. Open Leaderboard and explain that seeded cohort entries are demo data.
7. Open Insights to explain SM-2 and the forgetting curve.

## Important notes for an honest demo
- A grade of 5 on a card's first successful review schedules it in 1 day under the standard SM-2 sequence; the next successful review schedules it in 6 days. This corrects a common inconsistency in simplified demo briefs.
- Streaks use UTC ISO dates to avoid timezone drift. For a production campus app, use a server-authoritative user timezone and authenticated accounts.
- The leaderboard includes seeded sample learners. A real multi-user campus leaderboard requires authentication and deployment of one shared server/database.
- AI flashcard generation is not wired to an API key. Do not expose private API keys in frontend JavaScript; connect a server-side LLM endpoint if this stretch feature is required.
