const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "data.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return { decks: [], users: [], reviews: [] }; }
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
app.get("/api/state", (_req, res) => res.json(loadDB()));
app.put("/api/state", (req, res) => {
  const state = req.body;
  if (!state || !Array.isArray(state.decks) || !Array.isArray(state.users) || !Array.isArray(state.reviews)) {
    return res.status(400).json({ error: "Invalid application state." });
  }
  saveDB(state);
  res.json({ ok: true });
});
app.get("/api/health", (_req, res) => res.json({ ok: true, app: "RecallRocket" }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`🚀 RecallRocket running at http://localhost:${PORT}`));
